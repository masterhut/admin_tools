import '/client/imports/views/query_templates_options/max_time_ms/max_time_ms.html';
import '/client/imports/views/query_templates_options/project/project';
import '/client/imports/views/query_templates_options/sort/sort';
import '/client/imports/views/query_templates_options/return_original/return_original';
import '/client/imports/views/query_templates_options/upsert/upsert';
import '/client/imports/views/query_templates_options/array_filters/array_filters';
import './findone_modify_options.html';

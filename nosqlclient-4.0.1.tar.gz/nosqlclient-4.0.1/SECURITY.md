# Security Policy

## Supported Versions

We no longer support prior 4.0.0 versions.

| Version | Supported          |
| ------- | ------------------ |
| 4.0.0   | :white_check_mark: |
| < 4.0   | :x:                |

## Reporting a Vulnerability

Just use github issues :)

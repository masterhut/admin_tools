If you're having an issue _installing_ Electron, this is the place to report it.

If you're having an issue _using_ Electron, please report it at https://github.com/electron/electron/issues

* Electron version:
* Operating system:

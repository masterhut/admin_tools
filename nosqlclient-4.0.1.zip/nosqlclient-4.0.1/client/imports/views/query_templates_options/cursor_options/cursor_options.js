import '/client/imports/views/query_templates_options/max/max';
import '/client/imports/views/query_templates_options/project/project';
import '/client/imports/views/query_templates_options/min/min';
import '/client/imports/views/query_templates_options/sort/sort';
import '/client/imports/views/query_templates_options/limit/limit.html';
import '/client/imports/views/query_templates_options/skip/skip.html';
import '/client/imports/views/query_templates_options/hint/hint';
import './cursor_options.html';

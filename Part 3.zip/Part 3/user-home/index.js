'use strict';
module.exports = require('os-homedir')();

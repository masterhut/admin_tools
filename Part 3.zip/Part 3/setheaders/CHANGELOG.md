v0.1.7 / 2016-09-12
==================

  * Update devDependencies

v0.1.6 / 2016-08-29
==================

  * Tested against `node`@6

v0.1.5 / 2015-11-05
==================

  * Tested against `node`@5

v0.1.4 / 2015-09-06
==================

  * Tested against `iojs`@3

v0.1.3 / 2015-08-03
==================

  * SPDX license

v0.1.1 / 2015-02-25
==================

  * Fix npm `coverage` dir
  * Improve shortcut methods

v0.1.0 / 2015-02-23
==================

  * Change "override" option, from `false` to `true`
  * Add "writable" (options)
  * Add setHeader.setProctedHeader shortcut
  * Add setHeader.setOverrideHeader shortcut
  * Add setHeader.setWritableHeader shortcut
  * `coveralls` test

v0.0.5 / 2015-02-04
==================

  * Fix npm engines check

v0.0.4 / 2015-02-04
==================

  * `windows` test
  * `iojs` test

v0.0.3 / 2015-01-10
==================

  * Add setter to prevent set error

v0.0.2 / 2014-11-14
==================

  * Fix `undefined` key

v0.0.1 / 2014-11-13
==================

  * Project start

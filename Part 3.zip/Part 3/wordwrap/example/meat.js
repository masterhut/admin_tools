var wrap = require('wordwrap')(15);

console.log(wrap('You and your whole family are made out of meat.'));

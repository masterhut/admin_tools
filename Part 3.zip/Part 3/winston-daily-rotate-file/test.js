'use strict';

var winston = require('winston');
require('./index');

var transport = new winston.transports.DailyRotateFile({
  filename: './log',
  datePattern: 'yyyy-MM-dd-HH-mm.',
  prepend: true,
  level: process.env.ENV === 'development' ? 'debug' : 'info'
});

var logger = new (winston.Logger)({
  transports: [
    transport
  ]
});

logger.info('Hello World!');

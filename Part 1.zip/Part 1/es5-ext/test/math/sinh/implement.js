"use strict";

var isImplemented = require("../../../math/sinh/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };

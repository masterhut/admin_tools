"use strict";

var isImplemented = require("../../../math/log2/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };

"use strict";

var isImplemented = require("../../../number/max-safe-integer/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };

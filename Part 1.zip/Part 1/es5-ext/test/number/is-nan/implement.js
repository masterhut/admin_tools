"use strict";

var isImplemented = require("../../../number/is-nan/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };

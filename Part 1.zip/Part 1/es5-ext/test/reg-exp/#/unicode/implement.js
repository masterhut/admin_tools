"use strict";

var isImplemented = require("../../../../reg-exp/#/unicode/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };

"use strict";

var isImplemented = require("../../../../string/#/ends-with/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };

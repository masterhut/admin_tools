(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var HttpBasicAuth;

(function(){

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/jabbslad_basic-auth/packages/jabbslad_basic-auth.js                  //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
(function () {

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// packages/jabbslad:basic-auth/basic-auth.js                              //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
HttpBasicAuth = (function() {                                              // 1
  var HttpBasicAuth = function(callback, realm) {                          // 2
    this.callback = callback;                                              // 3
    this.realm = realm;                                                    // 4
  }                                                                        // 5
                                                                           // 6
  HttpBasicAuth.prototype = {                                              // 7
    constructor: HttpBasicAuth,                                            // 8
    protect: function(routes) {                                            // 9
      var basicAuth = WebAppInternals.NpmModules.connect.module.basicAuth; // 10
                                                                           // 11
      routes = routes || [''];                                             // 12
      if (!_.isArray(routes))                                              // 13
        throw new Error("'routes' must be an array of route Strings");     // 14
                                                                           // 15
      // Splice the middleware stack and slip in the auth function         // 16
      // so it is called first at desired routes (in specified order)      // 17
      for(var i=0; i<routes.length; i++) {                                 // 18
        WebApp.connectHandlers.stack.splice(i, 0, {                        // 19
          route: routes[i],                                                // 20
          handle: basicAuth(this.callback, this.realm)                     // 21
        });                                                                // 22
      }                                                                    // 23
    }                                                                      // 24
  };                                                                       // 25
                                                                           // 26
  return HttpBasicAuth;                                                    // 27
})();                                                                      // 28
                                                                           // 29
/////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['jabbslad:basic-auth'] = {}, {
  HttpBasicAuth: HttpBasicAuth
});

})();

(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['arch:ace-editor'] = {};

})();

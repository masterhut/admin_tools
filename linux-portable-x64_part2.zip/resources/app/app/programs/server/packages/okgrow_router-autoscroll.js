(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['okgrow:router-autoscroll'] = {};

})();

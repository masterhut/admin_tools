var require = meteorInstall({"lib":{"imports":{"collections.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/imports/collections.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
  Actions: function () {                                                                                               // 1
    return Actions;                                                                                                    // 1
  },                                                                                                                   // 1
  Connections: function () {                                                                                           // 1
    return Connections;                                                                                                // 1
  },                                                                                                                   // 1
  Dumps: function () {                                                                                                 // 1
    return Dumps;                                                                                                      // 1
  },                                                                                                                   // 1
  QueryHistory: function () {                                                                                          // 1
    return QueryHistory;                                                                                               // 1
  },                                                                                                                   // 1
  SchemaAnalyzeResult: function () {                                                                                   // 1
    return SchemaAnalyzeResult;                                                                                        // 1
  },                                                                                                                   // 1
  Settings: function () {                                                                                              // 1
    return Settings;                                                                                                   // 1
  },                                                                                                                   // 1
  ShellCommands: function () {                                                                                         // 1
    return ShellCommands;                                                                                              // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var Mongo = void 0;                                                                                                    // 1
module.watch(require("meteor/mongo"), {                                                                                // 1
  Mongo: function (v) {                                                                                                // 1
    Mongo = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Actions = new Mongo.Collection('actions');                                                                         // 3
var Connections = new Mongo.Collection('connections');                                                                 // 4
var Dumps = new Mongo.Collection('dump_logs');                                                                         // 5
var QueryHistory = new Mongo.Collection('query_histories');                                                            // 6
var SchemaAnalyzeResult = new Mongo.Collection('schema_analyze_result');                                               // 7
var Settings = new Mongo.Collection('settings');                                                                       // 8
var ShellCommands = new Mongo.Collection('shell_commands');                                                            // 9
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"imports":{"internal":{"internal_methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/internal/internal_methods.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
    parseUrl: function () {                                                                                            // 1
        return parseUrl;                                                                                               // 1
    }                                                                                                                  // 1
});                                                                                                                    // 1
var Meteor = void 0;                                                                                                   // 1
module.watch(require("meteor/meteor"), {                                                                               // 1
    Meteor: function (v) {                                                                                             // 1
        Meteor = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var Actions = void 0,                                                                                                  // 1
    QueryHistory = void 0,                                                                                             // 1
    Settings = void 0,                                                                                                 // 1
    Connections = void 0,                                                                                              // 1
    SchemaAnalyzeResult = void 0;                                                                                      // 1
module.watch(require("/lib/imports/collections"), {                                                                    // 1
    Actions: function (v) {                                                                                            // 1
        Actions = v;                                                                                                   // 1
    },                                                                                                                 // 1
    QueryHistory: function (v) {                                                                                       // 1
        QueryHistory = v;                                                                                              // 1
    },                                                                                                                 // 1
    Settings: function (v) {                                                                                           // 1
        Settings = v;                                                                                                  // 1
    },                                                                                                                 // 1
    Connections: function (v) {                                                                                        // 1
        Connections = v;                                                                                               // 1
    },                                                                                                                 // 1
    SchemaAnalyzeResult: function (v) {                                                                                // 1
        SchemaAnalyzeResult = v;                                                                                       // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var mailchimpAPI = void 0;                                                                                             // 1
module.watch(require("meteor/universe:mailchimp-v3-api"), {                                                            // 1
    "default": function (v) {                                                                                          // 1
        mailchimpAPI = v;                                                                                              // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var HTTP = void 0;                                                                                                     // 1
module.watch(require("meteor/http"), {                                                                                 // 1
    HTTP: function (v) {                                                                                               // 1
        HTTP = v;                                                                                                      // 1
    }                                                                                                                  // 1
}, 3);                                                                                                                 // 1
var LOGGER = void 0;                                                                                                   // 1
module.watch(require("../internal/logger"), {                                                                          // 1
    "default": function (v) {                                                                                          // 1
        LOGGER = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 4);                                                                                                                 // 1
                                                                                                                       //
var fs = require('fs');                                                                                                // 10
                                                                                                                       //
var packageJson = require('/package.json');                                                                            // 11
                                                                                                                       //
var mongodbUrlParser = require('parse-mongo-url');                                                                     // 12
                                                                                                                       //
var checkAuthenticationOfConnection = function (connection) {                                                          // 14
    LOGGER.info('[checkAuthenticationOfConnection]', connection.authenticationType);                                   // 15
    if (connection.authenticationType !== 'scram_sha_1') delete connection.scram_sha_1;                                // 16
    if (connection.authenticationType !== 'mongodb_cr') delete connection.mongodb_cr;                                  // 17
    if (connection.authenticationType !== 'mongodb_x509') delete connection.mongodb_x509;                              // 18
    if (connection.authenticationType !== 'gssapi') delete connection.gssapi;                                          // 19
    if (connection.authenticationType !== 'plain') delete connection.plain;                                            // 20
    if (connection.mongodb_x509) delete connection.ssl;                                                                // 22
    if (connection.gssapi && !connection.gssapi.serviceName) throw new Meteor.Error('Service name is required for GSSAPI !'); //if (connection.authenticationType && !connection[connection.authenticationType].username) throw new Meteor.Error('Username is required for this authentication type !');
};                                                                                                                     // 26
                                                                                                                       //
var parseUrl = function (connection) {                                                                                 // 28
    try {                                                                                                              // 29
        LOGGER.info('[parseUrl]', connection.url);                                                                     // 30
        var parsedUrl = mongodbUrlParser(connection.url);                                                              // 31
        connection.options = connection.options || {};                                                                 // 32
        connection.ssl = connection.ssl || {};                                                                         // 33
        connection.databaseName = parsedUrl.dbName || 'admin';                                                         // 34
        connection.servers = parsedUrl.servers;                                                                        // 35
                                                                                                                       //
        if (parsedUrl.server_options) {                                                                                // 36
            connection.options.connectionTimeout = parsedUrl.server_options.socketOptions && parsedUrl.server_options.socketOptions.connectTimeoutMS ? parsedUrl.server_options.socketOptions.connectTimeoutMS : "";
            connection.options.socketTimeout = parsedUrl.server_options.socketOptions && parsedUrl.server_options.socketOptions.socketTimeoutMS ? parsedUrl.server_options.socketOptions.socketTimeoutMS : "";
            connection.ssl.enabled = !!parsedUrl.server_options.ssl;                                                   // 39
        }                                                                                                              // 40
                                                                                                                       //
        connection.options.replicaSetName = parsedUrl.rs_options && parsedUrl.rs_options.rs_name ? parsedUrl.rs_options.rs_name : '';
        connection.options.readPreference = parsedUrl.db_options.read_preference;                                      // 42
        connection.authenticationType = parsedUrl.db_options.authMechanism ? parsedUrl.db_options.authMechanism.toLowerCase().replace(new RegExp("-", 'g'), "_") : '';
        if (connection.authenticationType) connection[connection.authenticationType] = {};                             // 44
        if (parsedUrl.db_options.gssapiServiceName && connection.authenticationType === 'gssapi') connection.gssapi.serviceName = parsedUrl.db_options.gssapiServiceName;
        if (connection.authenticationType === 'mongodb_x509') delete connection.ssl;                                   // 46
                                                                                                                       //
        if (parsedUrl.auth) {                                                                                          // 48
            // if auth exists there should be an authentication, even there's no authMechanism set                     // 49
            connection.authenticationType = connection.authenticationType || 'scram_sha_1';                            // 50
            connection[connection.authenticationType] = connection[connection.authenticationType] || {};               // 51
            connection[connection.authenticationType].username = parsedUrl.auth.user ? parsedUrl.auth.user : '';       // 52
            connection[connection.authenticationType].password = parsedUrl.auth.password ? parsedUrl.auth.password : '';
        }                                                                                                              // 54
                                                                                                                       //
        if (connection.authenticationType === 'mongodb_cr' || connection.authenticationType === 'scram_sha_1') {       // 55
            connection[connection.authenticationType].authSource = parsedUrl.db_options.authSource ? parsedUrl.db_options.authSource : connection.databaseName;
        }                                                                                                              // 57
                                                                                                                       //
        return connection;                                                                                             // 59
    } catch (ex) {                                                                                                     // 60
        LOGGER.error('[parseUrl]', connection.url, ex);                                                                // 62
        throw new Meteor.Error(ex.message);                                                                            // 63
    }                                                                                                                  // 64
};                                                                                                                     // 65
                                                                                                                       //
var checkConnection = function (connection) {                                                                          // 67
    LOGGER.info('[checkConnection]', JSON.stringify(connection));                                                      // 68
    if (connection.url) connection = parseUrl(connection);                                                             // 69
    if (connection.servers.length === 0) throw new Meteor.Error('At least one server is required !');else {            // 71
        for (var _iterator = connection.servers, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
            var _ref;                                                                                                  // 73
                                                                                                                       //
            if (_isArray) {                                                                                            // 73
                if (_i >= _iterator.length) break;                                                                     // 73
                _ref = _iterator[_i++];                                                                                // 73
            } else {                                                                                                   // 73
                _i = _iterator.next();                                                                                 // 73
                if (_i.done) break;                                                                                    // 73
                _ref = _i.value;                                                                                       // 73
            }                                                                                                          // 73
                                                                                                                       //
            var server = _ref;                                                                                         // 73
            if (!server.host || !server.port) throw new Meteor.Error('Host and port is required for each server !');   // 74
        }                                                                                                              // 75
    }                                                                                                                  // 76
    checkAuthenticationOfConnection(connection);                                                                       // 77
    if (connection.ssl && !connection.ssl.enabled) delete connection.ssl;                                              // 79
                                                                                                                       //
    if (connection.ssh) {                                                                                              // 80
        if (!connection.ssh.enabled) delete connection.ssh;                                                            // 81
        if (!connection.ssh.destinationPort) throw new Meteor.Error('Destination port is required for SSH !');         // 82
        if (!connection.ssh.username) throw new Meteor.Error('Username is required for SSH !');                        // 83
        if (!connection.ssh.host) throw new Meteor.Error('Host is required for SSH !');                                // 84
        if (!connection.ssh.port) throw new Meteor.Error('Port is required for SSH !');                                // 85
        if (!connection.ssh.certificateFileName && !connection.ssh.password) throw new Meteor.Error('Either certificate or password is required for SSH !');
    }                                                                                                                  // 87
};                                                                                                                     // 89
                                                                                                                       //
var saveConnectionToDB = function (connection) {                                                                       // 91
    LOGGER.info('[saveConnectionToDB]', JSON.stringify(connection));                                                   // 92
                                                                                                                       //
    if (connection._id) {                                                                                              // 93
        Connections.remove({                                                                                           // 94
            _id: connection._id                                                                                        // 94
        });                                                                                                            // 94
    }                                                                                                                  // 95
                                                                                                                       //
    Connections.insert(connection);                                                                                    // 97
};                                                                                                                     // 98
                                                                                                                       //
Meteor.methods({                                                                                                       // 100
    subscribed: function () {                                                                                          // 101
        LOGGER.info('[subscriber]', 'setting as subscribed');                                                          // 102
        Settings.update({}, {                                                                                          // 103
            $set: {                                                                                                    // 104
                subscribed: true                                                                                       // 104
            }                                                                                                          // 104
        });                                                                                                            // 103
    },                                                                                                                 // 106
    handleSubscriber: function (email) {                                                                               // 108
        LOGGER.info('[subscriber]', email);                                                                            // 109
        var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                                                                                                                       //
        if (!regex.test(email)) {                                                                                      // 111
            LOGGER.error('[subscriber]', 'not valid email: ' + email);                                                 // 112
            throw new Meteor.Error(400, 'Not a valid email address !');                                                // 113
        }                                                                                                              // 114
                                                                                                                       //
        return mailchimpAPI.setApiKey('96b3d560f7ce4cdf78a65383375ee73b-us15').addANewListMember({                     // 115
            list_id: 'ff8b28a54d',                                                                                     // 116
            body: {                                                                                                    // 117
                email_address: email,                                                                                  // 118
                status: 'subscribed'                                                                                   // 119
            }                                                                                                          // 117
        }).then(null, function (reason) {                                                                              // 115
            LOGGER.error('[subscribe]', reason.response.statusCode, JSON.parse(reason.response.content).title);        // 122
            throw new Meteor.Error(reason.response.statusCode, JSON.parse(reason.response.content).title);             // 123
        });                                                                                                            // 124
    },                                                                                                                 // 126
    checkMongoclientVersion: function () {                                                                             // 128
        try {                                                                                                          // 129
            LOGGER.info('[checkNosqlclientVersion]');                                                                  // 130
            var response = HTTP.get('https://api.github.com/repos/nosqlclient/nosqlclient/releases/latest', {          // 131
                headers: {                                                                                             // 131
                    "User-Agent": "Mongoclient"                                                                        // 131
                }                                                                                                      // 131
            });                                                                                                        // 131
                                                                                                                       //
            if (response && response.data && response.data.name && response.data.name !== packageJson.version) {       // 132
                return "There's a new version of mongoclient: " + response.data.name + ", <a href='https://github.com/nosqlclient/nosqlclient/releases/latest' target='_blank'>download here</a>, if you're using docker just use pull for the <b>" + response.data.name + "</b> or <b>latest</b> tag !";
            }                                                                                                          // 134
        } catch (e) {                                                                                                  // 135
            LOGGER.error('[checkNosqlclientVersion]', e);                                                              // 136
            return null;                                                                                               // 137
        }                                                                                                              // 138
    },                                                                                                                 // 139
    removeSchemaAnalyzeResult: function (sessionId) {                                                                  // 141
        LOGGER.info('[removeSchemaAnalyzeResult]', sessionId);                                                         // 142
        SchemaAnalyzeResult.remove({                                                                                   // 143
            sessionId: sessionId                                                                                       // 143
        });                                                                                                            // 143
    },                                                                                                                 // 144
    saveActions: function (action) {                                                                                   // 146
        LOGGER.info('[saveActions]', action);                                                                          // 147
        Actions.insert(action);                                                                                        // 148
    },                                                                                                                 // 149
    saveQueryHistory: function (history) {                                                                             // 151
        LOGGER.info('[saveQueryHistory]', history);                                                                    // 152
        var queryHistoryCount = QueryHistory.find({                                                                    // 153
            connectionId: history.connectionId,                                                                        // 154
            collectionName: history.collectionName                                                                     // 155
        }).count();                                                                                                    // 153
                                                                                                                       //
        if (queryHistoryCount >= 20) {                                                                                 // 158
            QueryHistory.remove(QueryHistory.findOne({}, {                                                             // 159
                sort: {                                                                                                // 159
                    date: 1                                                                                            // 159
                }                                                                                                      // 159
            })._id);                                                                                                   // 159
        }                                                                                                              // 160
                                                                                                                       //
        QueryHistory.insert(history);                                                                                  // 162
    },                                                                                                                 // 163
    updateSettings: function (settings) {                                                                              // 165
        try {                                                                                                          // 166
            LOGGER.info('[updateSettings]', JSON.stringify(settings));                                                 // 167
            Settings.remove({});                                                                                       // 168
            Settings.insert(settings);                                                                                 // 169
        } catch (ex) {                                                                                                 // 170
            LOGGER.error('[updateSettings]', ex);                                                                      // 172
            throw new Meteor.Error(ex.message);                                                                        // 173
        }                                                                                                              // 174
    },                                                                                                                 // 175
    saveConnection: function (connection) {                                                                            // 177
        LOGGER.info('[saveConnection]', JSON.stringify(connection));                                                   // 178
        saveConnectionToDB(connection);                                                                                // 179
    },                                                                                                                 // 180
    checkAndSaveConnection: function (connection) {                                                                    // 182
        LOGGER.info('[checkAndSaveConnection]', JSON.stringify(connection));                                           // 183
        checkConnection(connection);                                                                                   // 184
                                                                                                                       //
        if (!connection.databaseName) {                                                                                // 186
            connection.databaseName = 'admin';                                                                         // 187
        }                                                                                                              // 188
                                                                                                                       //
        saveConnectionToDB(connection);                                                                                // 190
    },                                                                                                                 // 191
    parseUrl: function (connection) {                                                                                  // 193
        return parseUrl(connection);                                                                                   // 194
    },                                                                                                                 // 195
    removeConnection: function (connectionId) {                                                                        // 197
        LOGGER.info('[removeConnection]', connectionId);                                                               // 198
        Connections.remove(connectionId);                                                                              // 199
        QueryHistory.remove({                                                                                          // 200
            connectionId: connectionId                                                                                 // 200
        });                                                                                                            // 200
    }                                                                                                                  // 201
});                                                                                                                    // 100
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logger.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/internal/logger.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by RSercan on 5.3.2016.                                                                                     //
 */var winston = require('winston');                                                                                   //
                                                                                                                       //
module.exportDefault(new winston.Logger({                                                                              // 1
    transports: [new winston.transports.Console({                                                                      // 7
        'timestamp': true                                                                                              // 8
    })]                                                                                                                // 8
}));                                                                                                                   // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"startup.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/internal/startup.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
    migrateConnectionsIfExist: function () {                                                                           // 1
        return migrateConnectionsIfExist;                                                                              // 1
    }                                                                                                                  // 1
});                                                                                                                    // 1
var Meteor = void 0;                                                                                                   // 1
module.watch(require("meteor/meteor"), {                                                                               // 1
    Meteor: function (v) {                                                                                             // 1
        Meteor = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var Settings = void 0,                                                                                                 // 1
    Connections = void 0,                                                                                              // 1
    Dumps = void 0,                                                                                                    // 1
    ShellCommands = void 0,                                                                                            // 1
    SchemaAnalyzeResult = void 0;                                                                                      // 1
module.watch(require("/lib/imports/collections"), {                                                                    // 1
    Settings: function (v) {                                                                                           // 1
        Settings = v;                                                                                                  // 1
    },                                                                                                                 // 1
    Connections: function (v) {                                                                                        // 1
        Connections = v;                                                                                               // 1
    },                                                                                                                 // 1
    Dumps: function (v) {                                                                                              // 1
        Dumps = v;                                                                                                     // 1
    },                                                                                                                 // 1
    ShellCommands: function (v) {                                                                                      // 1
        ShellCommands = v;                                                                                             // 1
    },                                                                                                                 // 1
    SchemaAnalyzeResult: function (v) {                                                                                // 1
        SchemaAnalyzeResult = v;                                                                                       // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var HttpBasicAuth = void 0;                                                                                            // 1
module.watch(require("meteor/jabbslad:basic-auth"), {                                                                  // 1
    HttpBasicAuth: function (v) {                                                                                      // 1
        HttpBasicAuth = v;                                                                                             // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var parseUrl = void 0;                                                                                                 // 1
module.watch(require("./internal_methods"), {                                                                          // 1
    parseUrl: function (v) {                                                                                           // 1
        parseUrl = v;                                                                                                  // 1
    }                                                                                                                  // 1
}, 3);                                                                                                                 // 1
                                                                                                                       //
var migrateConnectionsIfExist = function () {                                                                          // 12
    var settings = Settings.findOne();                                                                                 // 13
    if (settings.isMigrationDone) return;                                                                              // 14
    var connectionsAfterMigration = [];                                                                                // 16
                                                                                                                       //
    for (var _iterator = Connections.find().fetch(), _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
        var _ref;                                                                                                      // 18
                                                                                                                       //
        if (_isArray) {                                                                                                // 18
            if (_i >= _iterator.length) break;                                                                         // 18
            _ref = _iterator[_i++];                                                                                    // 18
        } else {                                                                                                       // 18
            _i = _iterator.next();                                                                                     // 18
            if (_i.done) break;                                                                                        // 18
            _ref = _i.value;                                                                                           // 18
        }                                                                                                              // 18
                                                                                                                       //
        var oldConnection = _ref;                                                                                      // 18
        // if there's a name (was mandatory) property it's old.                                                        // 19
        if (!oldConnection.name) continue;                                                                             // 20
        var connection = {                                                                                             // 22
            options: {}                                                                                                // 22
        };                                                                                                             // 22
                                                                                                                       //
        if (oldConnection.url) {                                                                                       // 23
            connection = parseUrl({                                                                                    // 24
                url: oldConnection.url                                                                                 // 24
            });                                                                                                        // 24
            connection.url = oldConnection.url;                                                                        // 25
        }                                                                                                              // 26
                                                                                                                       //
        connection._id = oldConnection._id;                                                                            // 28
        connection.connectionName = oldConnection.name;                                                                // 29
        migrateSSHPart(oldConnection, connection);                                                                     // 31
                                                                                                                       //
        if (oldConnection.host && oldConnection.port) {                                                                // 32
            connection.servers = [{                                                                                    // 33
                host: oldConnection.host,                                                                              // 34
                port: oldConnection.port                                                                               // 35
            }];                                                                                                        // 33
        }                                                                                                              // 37
                                                                                                                       //
        if (oldConnection.readFromSecondary) connection.options.readPreference = "secondary";else connection.options.readPreference = "primary";
        if (oldConnection.databaseName) connection.databaseName = oldConnection.databaseName;                          // 41
                                                                                                                       //
        if (oldConnection.user && oldConnection.password) {                                                            // 43
            connection.scram_sha_1 = {                                                                                 // 44
                username: oldConnection.user,                                                                          // 45
                password: oldConnection.password                                                                       // 46
            };                                                                                                         // 44
            if (oldConnection.authDatabaseName) connection.scram_sha_1.authSource = oldConnection.authDatabaseName;    // 48
            connection.authenticationType = "scram_sha_1";                                                             // 49
        }                                                                                                              // 50
                                                                                                                       //
        if (oldConnection.useSsl || oldConnection.sslCertificatePath) connection.ssl = {                               // 52
            enabled: true                                                                                              // 52
        };                                                                                                             // 52
                                                                                                                       //
        if (oldConnection.x509Username) {                                                                              // 54
            connection.authenticationType = "mongodb_x509";                                                            // 55
            connection.mongodb_x509 = {                                                                                // 56
                username: oldConnection.x509Username                                                                   // 56
            };                                                                                                         // 56
            delete connection.ssl;                                                                                     // 57
        }                                                                                                              // 58
                                                                                                                       //
        if (oldConnection.sslCertificatePath) {                                                                        // 60
            var objToChange = oldConnection.x509Username ? connection.mongodb_x509 : connection.ssl;                   // 61
            objToChange.certificateFile = oldConnection.sslCertificate;                                                // 62
            objToChange.certificateFileName = oldConnection.sslCertificatePath;                                        // 63
            objToChange.passPhrase = oldConnection.passPhrase;                                                         // 64
                                                                                                                       //
            if (oldConnection.rootCACertificatePath) {                                                                 // 65
                objToChange.rootCAFile = oldConnection.rootCACertificate;                                              // 66
                objToChange.rootCAFileName = oldConnection.rootCACertificatePath;                                      // 67
            }                                                                                                          // 68
                                                                                                                       //
            if (oldConnection.certificateKeyPath) {                                                                    // 69
                objToChange.certificateKeyFile = oldConnection.certificateKey;                                         // 70
                objToChange.certificateKeyFileName = oldConnection.certificateKeyPath;                                 // 71
            }                                                                                                          // 72
        }                                                                                                              // 73
                                                                                                                       //
        connectionsAfterMigration.push(connection);                                                                    // 75
    }                                                                                                                  // 76
                                                                                                                       //
    Connections.remove({});                                                                                            // 79
                                                                                                                       //
    for (var _iterator2 = connectionsAfterMigration, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
        var _ref2;                                                                                                     // 80
                                                                                                                       //
        if (_isArray2) {                                                                                               // 80
            if (_i2 >= _iterator2.length) break;                                                                       // 80
            _ref2 = _iterator2[_i2++];                                                                                 // 80
        } else {                                                                                                       // 80
            _i2 = _iterator2.next();                                                                                   // 80
            if (_i2.done) break;                                                                                       // 80
            _ref2 = _i2.value;                                                                                         // 80
        }                                                                                                              // 80
                                                                                                                       //
        var conn = _ref2;                                                                                              // 80
        Connections.insert(conn);                                                                                      // 80
    }                                                                                                                  // 80
                                                                                                                       //
    Settings.update({}, {                                                                                              // 82
        $set: {                                                                                                        // 83
            isMigrationDone: true                                                                                      // 84
        }                                                                                                              // 83
    });                                                                                                                // 82
};                                                                                                                     // 87
                                                                                                                       //
var migrateSSHPart = function (oldConnection, connection) {                                                            // 89
    if (oldConnection.sshAddress) {                                                                                    // 90
        connection.ssh = {                                                                                             // 91
            enabled: true,                                                                                             // 92
            host: oldConnection.sshAddress,                                                                            // 93
            port: oldConnection.sshPort,                                                                               // 94
            username: oldConnection.sshUser,                                                                           // 95
            destinationPort: oldConnection.sshPort                                                                     // 96
        };                                                                                                             // 91
        if (oldConnection.sshPassword) connection.ssh.password = oldConnection.sshPassword;else {                      // 99
            connection.ssh.certificateFile = oldConnection.sshCertificate;                                             // 101
            connection.ssh.certificateFileName = oldConnection.sshCertificatePath;                                     // 102
            connection.ssh.passPhrase = oldConnection.sshPassPhrase;                                                   // 103
        }                                                                                                              // 104
    }                                                                                                                  // 105
};                                                                                                                     // 106
                                                                                                                       //
var tryInjectDefaultConnection = function () {                                                                         // 108
    var DEFAULT_CONNECTION_NAME = "Default (preconfigured)";                                                           // 109
    var defaultConnection = process.env.MONGOCLIENT_DEFAULT_CONNECTION_URL;                                            // 110
    if (!defaultConnection) return;                                                                                    // 111
    var connection = parseUrl({                                                                                        // 113
        url: defaultConnection                                                                                         // 113
    });                                                                                                                // 113
    connection.url = defaultConnection;                                                                                // 114
    connection.connectionName = DEFAULT_CONNECTION_NAME; // delete existing connection after we parsed the new one     // 115
                                                                                                                       //
    var existingConnection = Connections.findOne({                                                                     // 118
        connectionName: DEFAULT_CONNECTION_NAME                                                                        // 118
    });                                                                                                                // 118
                                                                                                                       //
    if (existingConnection) {                                                                                          // 119
        Connections.remove(existingConnection._id);                                                                    // 120
        connection._id = existingConnection._id;                                                                       // 121
    }                                                                                                                  // 122
                                                                                                                       //
    Connections.insert(connection);                                                                                    // 124
};                                                                                                                     // 125
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 127
    var home = process.env.HOME || process.env.USERPROFILE;                                                            // 128
    home = home.replace(/\\/g, "/");                                                                                   // 129
                                                                                                                       //
    if (!Settings.findOne()) {                                                                                         // 130
        Settings.insert({                                                                                              // 131
            scale: "MegaBytes",                                                                                        // 132
            defaultResultView: "Jsoneditor",                                                                           // 133
            mongoBinaryPath: "/opt/mongodb/bin/",                                                                      // 134
            maxAllowedFetchSize: 3,                                                                                    // 135
            autoCompleteSamplesCount: 50,                                                                              // 136
            socketTimeoutInSeconds: 5,                                                                                 // 137
            connectionTimeoutInSeconds: 3,                                                                             // 138
            dbStatsScheduler: 3000,                                                                                    // 139
            showDBStats: true,                                                                                         // 140
            showLiveChat: true,                                                                                        // 141
            singleTabResultSets: false,                                                                                // 142
            maxLiveChartDataPoints: 15                                                                                 // 143
        });                                                                                                            // 131
    }                                                                                                                  // 145
                                                                                                                       //
    if (process.env.MONGOCLIENT_AUTH == 'true') {                                                                      // 147
        var basicAuth = new HttpBasicAuth(function (username, password) {                                              // 148
            return process.env.MONGOCLIENT_USERNAME == username && process.env.MONGOCLIENT_PASSWORD == password;       // 149
        });                                                                                                            // 150
        basicAuth.protect();                                                                                           // 151
    }                                                                                                                  // 152
                                                                                                                       //
    ShellCommands.remove({});                                                                                          // 154
    SchemaAnalyzeResult.remove({});                                                                                    // 155
    Dumps.remove({});                                                                                                  // 156
    migrateConnectionsIfExist();                                                                                       // 157
    tryInjectDefaultConnection();                                                                                      // 158
});                                                                                                                    // 159
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"mongodb":{"extended_json.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/mongodb/extended_json.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof2 = require("babel-runtime/helpers/typeof");                                                                //
                                                                                                                       //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                       //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
module.export({                                                                                                        // 1
    serialize: function () {                                                                                           // 1
        return serialize;                                                                                              // 1
    },                                                                                                                 // 1
    deserialize: function () {                                                                                         // 1
        return deserialize;                                                                                            // 1
    }                                                                                                                  // 1
});                                                                                                                    // 1
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by Sercan on 29.10.2016.                                                                                    //
 */var bson = require('bson');                                                                                         //
                                                                                                                       //
var Binary = bson.Binary,                                                                                              // 5
    Long = bson.Long,                                                                                                  // 5
    MaxKey = bson.MaxKey,                                                                                              // 5
    MinKey = bson.MinKey,                                                                                              // 5
    BSONRegExp = bson.BSONRegExp,                                                                                      // 5
    Timestamp = bson.Timestamp,                                                                                        // 5
    ObjectId = bson.ObjectId,                                                                                          // 5
    Code = bson.Code,                                                                                                  // 5
    Decimal128 = bson.Decimal128;                                                                                      // 5
                                                                                                                       //
var serialize = function (obj) {                                                                                       // 8
    // there are some other objects such as Math, Date etc..                                                           // 9
    if (obj && (typeof obj === "undefined" ? "undefined" : (0, _typeof3.default)(obj)) === 'object' && Object.prototype.toString.call(obj) !== '[object Array]' && serializeResult(obj)) {
        return serializeResult(obj);                                                                                   // 11
    }                                                                                                                  // 12
                                                                                                                       //
    for (var property in meteorBabelHelpers.sanitizeForInObject(obj)) {                                                // 14
        if (obj.hasOwnProperty(property) && obj[property] !== null) {                                                  // 15
            if ((0, _typeof3.default)(obj[property]) === 'object' && Object.prototype.toString.call(obj[property]) !== '[object Array]') {
                if (serializeResult(obj[property])) {                                                                  // 17
                    obj[property] = serializeResult(obj[property]);                                                    // 18
                } else {                                                                                               // 19
                    obj[property] = serialize(obj[property]);                                                          // 20
                }                                                                                                      // 21
            } else if (Object.prototype.toString.call(obj[property]) === '[object Array]') {                           // 22
                for (var i = 0; i < obj[property].length; i++) {                                                       // 24
                    if (obj[property][i] !== null && (0, _typeof3.default)(obj[property][i]) === 'object' && Object.prototype.toString.call(obj[property][i]) !== '[object Array]' && serializeResult(obj[property][i])) {
                        obj[property][i] = serializeResult(obj[property][i]);                                          // 26
                    } else {                                                                                           // 27
                        obj[property][i] = serialize(obj[property][i]);                                                // 29
                    }                                                                                                  // 30
                }                                                                                                      // 31
            }                                                                                                          // 32
        }                                                                                                              // 33
    }                                                                                                                  // 34
                                                                                                                       //
    return obj;                                                                                                        // 36
};                                                                                                                     // 37
                                                                                                                       //
var deserialize = function (obj) {                                                                                     // 39
    if (obj && Object.prototype.toString.call(obj) === '[object Object]' && deserializeResult(obj)) {                  // 40
        return deserializeResult(obj);                                                                                 // 41
    }                                                                                                                  // 42
                                                                                                                       //
    for (var property in meteorBabelHelpers.sanitizeForInObject(obj)) {                                                // 44
        if (obj.hasOwnProperty(property) && obj[property]) {                                                           // 45
            if (Object.prototype.toString.call(obj[property]) === '[object Object]') {                                 // 46
                if (deserializeResult(obj[property])) {                                                                // 47
                    obj[property] = deserializeResult(obj[property]);                                                  // 48
                } else {                                                                                               // 49
                    obj[property] = deserialize(obj[property]);                                                        // 50
                }                                                                                                      // 51
            } else if (Object.prototype.toString.call(obj[property]) === '[object Array]') {                           // 52
                for (var i = 0; i < obj[property].length; i++) {                                                       // 54
                    if (obj[property][i] !== null && Object.prototype.toString.call(obj[property][i]) === '[object Object]' && deserializeResult(obj[property][i])) {
                        obj[property][i] = deserializeResult(obj[property][i]);                                        // 56
                    } else {                                                                                           // 57
                        obj[property][i] = deserialize(obj[property][i]);                                              // 59
                    }                                                                                                  // 60
                }                                                                                                      // 61
            }                                                                                                          // 62
        }                                                                                                              // 63
    }                                                                                                                  // 64
                                                                                                                       //
    return obj;                                                                                                        // 66
};                                                                                                                     // 67
                                                                                                                       //
var deserializeResult = function (doc) {                                                                               // 69
    if (doc['$binary'] != undefined) {                                                                                 // 70
        return new Binary(new Buffer(doc['$binary'], 'base64'), new Buffer(doc['$type'], 'hex')[0]);                   // 71
    } else if (doc['$code'] != undefined) {                                                                            // 72
        return new Code(doc['$code'], doc['$scope']);                                                                  // 73
    } else if (doc['$date'] != undefined) {                                                                            // 74
        if (typeof doc['$date'] == 'string') {                                                                         // 75
            return new Date(doc['$date']);                                                                             // 76
        } else if ((0, _typeof3.default)(doc['$date']) == 'object' && doc['$date']['$numberLong']) {                   // 77
            var date = new Date();                                                                                     // 79
            date.setTime(parseInt(doc['$date']['$numberLong'], 10));                                                   // 80
            return date;                                                                                               // 81
        }                                                                                                              // 82
    } else if (doc['$numberLong'] != undefined) {                                                                      // 83
        return Long.fromString(doc['$numberLong']);                                                                    // 84
    } else if (doc['$maxKey'] != undefined) {                                                                          // 85
        return new MaxKey();                                                                                           // 86
    } else if (doc['$minKey'] != undefined) {                                                                          // 87
        return new MinKey();                                                                                           // 88
    } else if (doc['$oid'] != undefined) {                                                                             // 89
        return new ObjectId(new Buffer(doc['$oid'], 'hex'));                                                           // 90
    } else if (doc['$regex'] != undefined) {                                                                           // 91
        var options = doc['$options'];                                                                                 // 92
                                                                                                                       //
        if (!options) {                                                                                                // 93
            options = "";                                                                                              // 94
        }                                                                                                              // 95
                                                                                                                       //
        return new BSONRegExp(doc['$regex'], options);                                                                 // 96
    } else if (doc['$timestamp'] != undefined) {                                                                       // 97
        return new Timestamp(doc['$timestamp'].i, doc['$timestamp'].t);                                                // 98
    } else if (doc['$numberDecimal'] != undefined) {                                                                   // 99
        return new Decimal128.fromString(doc['$numberDecimal']);                                                       // 100
    } else if (doc['$undefined'] != undefined) {                                                                       // 101
        return undefined;                                                                                              // 102
    }                                                                                                                  // 103
};                                                                                                                     // 104
                                                                                                                       //
var serializeResult = function (doc) {                                                                                 // 106
    if (doc instanceof Binary || doc._bsontype == 'Binary') {                                                          // 107
        return {                                                                                                       // 108
            '$binary': doc.buffer.toString('base64'),                                                                  // 109
            '$type': new Buffer([doc.sub_type]).toString('hex')                                                        // 110
        };                                                                                                             // 108
    } else if (doc instanceof Code || doc._bsontype == 'Code') {                                                       // 112
        var res = {                                                                                                    // 113
            '$code': doc.code                                                                                          // 113
        };                                                                                                             // 113
        if (doc.scope) res['$scope'] = doc.scope;                                                                      // 114
        return res;                                                                                                    // 115
    } else if (doc instanceof Date) {                                                                                  // 116
        return {                                                                                                       // 117
            '$date': doc.toISOString()                                                                                 // 117
        };                                                                                                             // 117
    } else if (doc instanceof Long || doc._bsontype == 'Long') {                                                       // 118
        return {                                                                                                       // 119
            '$numberLong': doc.toString()                                                                              // 119
        };                                                                                                             // 119
    } else if (doc instanceof MaxKey || doc._bsontype == 'MaxKey') {                                                   // 120
        return {                                                                                                       // 121
            '$maxKey': true                                                                                            // 121
        };                                                                                                             // 121
    } else if (doc instanceof MinKey || doc._bsontype == 'MinKey') {                                                   // 122
        return {                                                                                                       // 123
            '$minKey': true                                                                                            // 123
        };                                                                                                             // 123
    } else if (doc instanceof ObjectId || doc._bsontype == 'ObjectID') {                                               // 124
        return {                                                                                                       // 125
            '$oid': doc.toString()                                                                                     // 125
        };                                                                                                             // 125
    } else if (doc instanceof BSONRegExp) {                                                                            // 126
        return {                                                                                                       // 127
            '$regex': doc.pattern,                                                                                     // 127
            '$options': doc.options                                                                                    // 127
        };                                                                                                             // 127
    } else if (doc instanceof Timestamp || doc._bsontype == 'Timestamp') {                                             // 128
        return {                                                                                                       // 129
            '$timestamp': {                                                                                            // 129
                t: doc.high_,                                                                                          // 129
                i: doc.low_                                                                                            // 129
            }                                                                                                          // 129
        };                                                                                                             // 129
    } else if (doc instanceof Decimal128 || doc._bsontype == 'Decimal128') {                                           // 130
        return {                                                                                                       // 131
            '$numberDecimal': doc.toString()                                                                           // 131
        };                                                                                                             // 131
    } else if (doc === undefined) {                                                                                    // 132
        return {                                                                                                       // 133
            '$undefined': true                                                                                         // 133
        };                                                                                                             // 133
    }                                                                                                                  // 134
};                                                                                                                     // 135
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"helper.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/mongodb/helper.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof2 = require("babel-runtime/helpers/typeof");                                                                //
                                                                                                                       //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                       //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
var Settings = void 0;                                                                                                 // 1
module.watch(require("/lib/imports/collections"), {                                                                    // 1
    Settings: function (v) {                                                                                           // 1
        Settings = v;                                                                                                  // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var deserialize = void 0,                                                                                              // 1
    serialize = void 0;                                                                                                // 1
module.watch(require("./extended_json"), {                                                                             // 1
    deserialize: function (v) {                                                                                        // 1
        deserialize = v;                                                                                               // 1
    },                                                                                                                 // 1
    serialize: function (v) {                                                                                          // 1
        serialize = v;                                                                                                 // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
                                                                                                                       //
var addOptionToUrl = function (url, option, value) {                                                                   // 7
    if (!value) return '';                                                                                             // 8
    if (url.substring(url.lastIndexOf('/')).indexOf('?') === -1) return '?' + option + '=' + value;                    // 9
    return '&' + option + '=' + value;                                                                                 // 11
};                                                                                                                     // 12
                                                                                                                       //
var getRoundedMilisecondsFromSeconds = function (sec) {                                                                // 14
    if (sec) return Math.round(sec * 100 * 1000) / 100;                                                                // 15
    return '30000';                                                                                                    // 16
};                                                                                                                     // 17
                                                                                                                       //
var addSSLOptions = function (obj, result) {                                                                           // 19
    if (obj.rootCAFile) {                                                                                              // 20
        result.sslValidate = true;                                                                                     // 21
        result.sslCA = new Buffer(obj.rootCAFile);                                                                     // 22
    }                                                                                                                  // 23
                                                                                                                       //
    if (obj.certificateFile) result.sslCert = new Buffer(obj.certificateFile);                                         // 24
    if (obj.certificateKeyFile) result.sslKey = new Buffer(obj.certificateKeyFile);                                    // 25
    if (obj.passPhrase) result.sslPass = obj.passPhrase;                                                               // 26
    if (obj.disableHostnameVerification) result.checkServerIdentity = false;                                           // 27
};                                                                                                                     // 28
                                                                                                                       //
var Helper = function () {};                                                                                           // 30
                                                                                                                       //
Helper.prototype = {                                                                                                   // 33
    extractDBFromConnectionUrl: function (connection) {                                                                // 34
        var options = "";                                                                                              // 35
                                                                                                                       //
        if (connection.url.indexOf('?') !== -1) {                                                                      // 36
            options = "?" + connection.url.split('?')[1];                                                              // 37
        }                                                                                                              // 38
                                                                                                                       //
        var splited = connection.url.split('/');                                                                       // 40
                                                                                                                       //
        if (splited.length <= 3) {                                                                                     // 41
            connection.url += "/" + options;                                                                           // 42
        } else {                                                                                                       // 43
            splited[3] = '';                                                                                           // 45
            connection.url = splited.join('/') + options;                                                              // 46
        }                                                                                                              // 47
    },                                                                                                                 // 48
    changeUsernameAndPasswordFromConnectionUrl: function (connection, username, password) {                            // 50
        var splitedForDash = connection.url.split('//');                                                               // 51
                                                                                                                       //
        if (connection.url.indexOf('@') !== -1) {                                                                      // 53
            var splitedForAt = splitedForDash[1].split('@');                                                           // 54
            var usernameAndPassword = splitedForAt[0].split(':');                                                      // 55
            if (!username && usernameAndPassword[0]) username = usernameAndPassword[0];                                // 56
            if (!password && usernameAndPassword.length >= 2 && usernameAndPassword[1]) password = usernameAndPassword[1];
            connection.url = splitedForDash[0] + "//" + username + ":" + password + "@" + splitedForAt[1];             // 59
        } else {                                                                                                       // 60
            connection.url = splitedForDash[0] + "//" + username + ":" + password + "@" + splitedForDash[1];           // 62
        }                                                                                                              // 63
    },                                                                                                                 // 64
    addAuthSourceToConnectionUrl: function (connection) {                                                              // 66
        if (connection.url.indexOf('authSource') !== -1) return;                                                       // 67
        connection.url += addOptionToUrl(connection.url, 'authSource', connection.databaseName);                       // 68
    },                                                                                                                 // 69
    getConnectionUrl: function (connection, addDB, username, password, addAuthSource) {                                // 71
        if (connection.url) {                                                                                          // 72
            if (username || password) this.changeUsernameAndPasswordFromConnectionUrl(connection, username, password);
            if (!addDB) this.extractDBFromConnectionUrl(connection);                                                   // 74
            if (addAuthSource) this.addAuthSourceToConnectionUrl(connection);                                          // 75
            return connection.url;                                                                                     // 77
        }                                                                                                              // 78
                                                                                                                       //
        var settings = Settings.findOne(); // url                                                                      // 80
                                                                                                                       //
        var connectionUrl = 'mongodb://';                                                                              // 83
                                                                                                                       //
        if (connection.authenticationType) {                                                                           // 84
            if (username) connectionUrl += encodeURIComponent(username);else if (connection[connection.authenticationType].username) connectionUrl += encodeURIComponent(connection[connection.authenticationType].username);
            if (password) connectionUrl += ':' + encodeURIComponent(password);else if (connection[connection.authenticationType].password) connectionUrl += ':' + encodeURIComponent(connection[connection.authenticationType].password);
            connectionUrl += "@";                                                                                      // 91
        }                                                                                                              // 92
                                                                                                                       //
        for (var _iterator = connection.servers, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
            var _ref;                                                                                                  // 93
                                                                                                                       //
            if (_isArray) {                                                                                            // 93
                if (_i >= _iterator.length) break;                                                                     // 93
                _ref = _iterator[_i++];                                                                                // 93
            } else {                                                                                                   // 93
                _i = _iterator.next();                                                                                 // 93
                if (_i.done) break;                                                                                    // 93
                _ref = _i.value;                                                                                       // 93
            }                                                                                                          // 93
                                                                                                                       //
            var server = _ref;                                                                                         // 93
            connectionUrl += server.host + ':' + server.port + ',';                                                    // 94
        }                                                                                                              // 95
                                                                                                                       //
        if (connectionUrl.endsWith(',')) connectionUrl = connectionUrl.substring(0, connectionUrl.length - 1);         // 96
        connectionUrl += "/";                                                                                          // 97
        if (addDB) connectionUrl += connection.databaseName; // options                                                // 98
                                                                                                                       //
        if (connection.authenticationType === 'mongodb_cr' || connection.authenticationType === 'scram_sha_1') connectionUrl += addOptionToUrl(connectionUrl, 'authSource', connection[connection.authenticationType].authSource);else if (connection.authenticationType === 'mongodb_x509') connectionUrl += addOptionToUrl(connectionUrl, 'ssl', 'true');else if (connection.authenticationType === 'gssapi' || connection.authenticationType === 'plain') {
            if (connection.authenticationType === 'gssapi') connectionUrl += addOptionToUrl(connectionUrl, 'gssapiServiceName', connection.gssapi.serviceName);
            connectionUrl += addOptionToUrl(connectionUrl, 'authSource', '$external');                                 // 105
        }                                                                                                              // 106
                                                                                                                       //
        if (connection.options) {                                                                                      // 108
            if (connection.options.readPreference) connectionUrl += addOptionToUrl(connectionUrl, 'readPreference', connection.options.readPreference);
            if (connection.options.connectionTimeout) connectionUrl += addOptionToUrl(connectionUrl, 'connectTimeoutMS', getRoundedMilisecondsFromSeconds(connection.options.connectionTimeout));else connectionUrl += addOptionToUrl(connectionUrl, 'connectTimeoutMS', getRoundedMilisecondsFromSeconds(settings.connectionTimeoutInSeconds));
            if (connection.options.socketTimeout) connectionUrl += addOptionToUrl(connectionUrl, 'socketTimeoutMS', getRoundedMilisecondsFromSeconds(connection.options.socketTimeout));else connectionUrl += addOptionToUrl(connectionUrl, 'socketTimeoutMS', getRoundedMilisecondsFromSeconds(settings.socketTimeoutInSeconds));
            if (connection.options.replicaSetName) connectionUrl += addOptionToUrl(connectionUrl, 'replicaSet', connection.options.replicaSetName);
        }                                                                                                              // 118
                                                                                                                       //
        if (connection.ssl && connection.ssl.enabled) connectionUrl += addOptionToUrl(connectionUrl, 'ssl', 'true');   // 120
        if (connection.authenticationType) connectionUrl += addOptionToUrl(connectionUrl, 'authMechanism', connection.authenticationType.toUpperCase().replace(new RegExp("_", 'g'), "-"));
                                                                                                                       //
        if (addAuthSource) {                                                                                           // 123
            if (connection.authenticationType === 'mongodb_cr' || connection.authenticationType === 'scram_sha_1') {   // 124
                if (connection[connection.authenticationType].authSource) connectionUrl += addOptionToUrl(connectionUrl, 'authSource', connection[connection.authenticationType].authSource);else connectionUrl += addOptionToUrl(connectionUrl, 'authSource', connection.databaseName);
            } else if (connection.authenticationType === 'gssapi' || connection.authenticationType === 'plain') {      // 127
                connectionUrl += addOptionToUrl(connectionUrl, 'authSource', '$external');                             // 129
            }                                                                                                          // 130
        }                                                                                                              // 131
                                                                                                                       //
        return connectionUrl;                                                                                          // 133
    },                                                                                                                 // 134
    getConnectionOptions: function (connection) {                                                                      // 136
        var result = {};                                                                                               // 137
        if (connection.authenticationType === 'mongodb_x509') addSSLOptions(connection.mongodb_x509, result);          // 138
        if (connection.ssl && connection.ssl.enabled) addSSLOptions(connection.ssl, result);                           // 139
        if (connection.options && connection.options.connectWithNoPrimary) result.connectWithNoPrimary = true; // added authSource to here to provide same authSource as DB name if it's not provided when connection is being used by URL
                                                                                                                       //
        if (connection.authenticationType === 'mongodb_cr' || connection.authenticationType === 'scram_sha_1') {       // 143
            if (connection[connection.authenticationType].authSource) result.authSource = connection[connection.authenticationType].authSource;else result.authSource = connection.databaseName;
        } else if (connection.authenticationType === 'gssapi' || connection.authenticationType === 'plain') {          // 146
            result.authSource = '$external';                                                                           // 148
        }                                                                                                              // 149
                                                                                                                       //
        return result;                                                                                                 // 150
    },                                                                                                                 // 151
    clearConnectionOptionsForLog: function (connectionOptions) {                                                       // 153
        var result = JSON.parse(JSON.stringify(connectionOptions));                                                    // 154
        delete result.sslCert;                                                                                         // 155
        delete result.sslCA;                                                                                           // 156
        delete result.sslKey;                                                                                          // 157
        return result;                                                                                                 // 159
    },                                                                                                                 // 160
    removeConnectionTopology: function (obj) {                                                                         // 162
        if (obj.result && (0, _typeof3.default)(obj.result) === 'object') {                                            // 163
            if ('connection' in obj.result) {                                                                          // 164
                delete obj.result.connection;                                                                          // 165
            }                                                                                                          // 166
        }                                                                                                              // 167
    },                                                                                                                 // 168
    removeCollectionTopology: function (obj) {                                                                         // 170
        if (obj.result && (0, _typeof3.default)(obj.result) === 'object') {                                            // 171
            obj.result = {};                                                                                           // 172
        }                                                                                                              // 173
    },                                                                                                                 // 174
    convertBSONtoJSON: function (obj) {                                                                                // 177
        return serialize(obj);                                                                                         // 178
    },                                                                                                                 // 179
    convertJSONtoBSON: function (obj) {                                                                                // 181
        return deserialize(obj);                                                                                       // 182
    }                                                                                                                  // 183
};                                                                                                                     // 33
module.exportDefault(new Helper());                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods_admin.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/mongodb/methods_admin.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var LOGGER = void 0;                                                                                                   // 1
module.watch(require("../internal/logger"), {                                                                          // 1
    "default": function (v) {                                                                                          // 1
        LOGGER = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var Helper = void 0;                                                                                                   // 1
module.watch(require("./helper"), {                                                                                    // 1
    "default": function (v) {                                                                                          // 1
        Helper = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var Meteor = void 0;                                                                                                   // 1
module.watch(require("meteor/meteor"), {                                                                               // 1
    Meteor: function (v) {                                                                                             // 1
        Meteor = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var databasesBySessionId = void 0;                                                                                     // 1
module.watch(require("./methods_common"), {                                                                            // 1
    databasesBySessionId: function (v) {                                                                               // 1
        databasesBySessionId = v;                                                                                      // 1
    }                                                                                                                  // 1
}, 3);                                                                                                                 // 1
                                                                                                                       //
var proceedQueryExecution = function (methodArray, runOnAdminDB, sessionId) {                                          // 11
    LOGGER.info(JSON.stringify(methodArray), runOnAdminDB, sessionId);                                                 // 12
    var result = Async.runSync(function (done) {                                                                       // 14
        try {                                                                                                          // 15
            var execution = runOnAdminDB ? databasesBySessionId[sessionId].admin() : databasesBySessionId[sessionId];  // 16
                                                                                                                       //
            for (var i = 0; i < methodArray.length; i++) {                                                             // 17
                var last = i == methodArray.length - 1;                                                                // 18
                var entry = methodArray[i];                                                                            // 19
                entry = Helper.convertJSONtoBSON(entry);                                                               // 20
                                                                                                                       //
                for (var key in meteorBabelHelpers.sanitizeForInObject(entry)) {                                       // 22
                    if (entry.hasOwnProperty(key)) {                                                                   // 23
                        if (last && key == Object.keys(entry)[Object.keys(entry).length - 1]) {                        // 24
                            entry[key].push(function (err, docs) {                                                     // 25
                                done(err, docs);                                                                       // 26
                            });                                                                                        // 27
                            execution[key].apply(execution, entry[key]);                                               // 28
                        } else {                                                                                       // 29
                            execution = execution[key].apply(execution, entry[key]);                                   // 31
                        }                                                                                              // 32
                    }                                                                                                  // 33
                }                                                                                                      // 34
            }                                                                                                          // 35
        } catch (ex) {                                                                                                 // 36
            LOGGER.error(methodArray, sessionId, ex);                                                                  // 38
            done(new Meteor.Error(ex.message), null);                                                                  // 39
        }                                                                                                              // 40
    });                                                                                                                // 41
    return Helper.convertBSONtoJSON(result);                                                                           // 43
};                                                                                                                     // 44
                                                                                                                       //
Meteor.methods({                                                                                                       // 46
    top: function (sessionId) {                                                                                        // 47
        LOGGER.info('[top]', sessionId);                                                                               // 48
        var result = Async.runSync(function (done) {                                                                   // 50
            try {                                                                                                      // 51
                databasesBySessionId[sessionId].executeDbAdminCommand({                                                // 52
                    top: 1                                                                                             // 52
                }, {}, function (err, res) {                                                                           // 52
                    done(err, res);                                                                                    // 53
                });                                                                                                    // 54
            } catch (ex) {                                                                                             // 55
                LOGGER.error('[top]', sessionId, ex);                                                                  // 57
                done(new Meteor.Error(ex.message), null);                                                              // 58
            }                                                                                                          // 59
        });                                                                                                            // 60
        return Helper.convertBSONtoJSON(result);                                                                       // 62
    },                                                                                                                 // 63
    dbStats: function (sessionId) {                                                                                    // 65
        LOGGER.info('[stats]', sessionId);                                                                             // 66
        var result = Async.runSync(function (done) {                                                                   // 68
            try {                                                                                                      // 69
                databasesBySessionId[sessionId].stats(function (err, docs) {                                           // 70
                    done(err, docs);                                                                                   // 71
                });                                                                                                    // 72
            } catch (ex) {                                                                                             // 73
                LOGGER.error('[stats]', sessionId, ex);                                                                // 75
                done(new Meteor.Error(ex.message), null);                                                              // 76
            }                                                                                                          // 77
        });                                                                                                            // 78
        return Helper.convertBSONtoJSON(result);                                                                       // 80
    },                                                                                                                 // 81
    validateCollection: function (collectionName, options, sessionId) {                                                // 83
        var methodArray = [{                                                                                           // 84
            "validateCollection": [collectionName, options]                                                            // 86
        }];                                                                                                            // 85
        return proceedQueryExecution(methodArray, true, sessionId);                                                    // 89
    },                                                                                                                 // 90
    setProfilingLevel: function (level, sessionId) {                                                                   // 92
        var methodArray = [{                                                                                           // 93
            "setProfilingLevel": [level]                                                                               // 95
        }];                                                                                                            // 94
        return proceedQueryExecution(methodArray, true, sessionId);                                                    // 98
    },                                                                                                                 // 99
    serverStatus: function (sessionId) {                                                                               // 101
        var methodArray = [{                                                                                           // 102
            "serverStatus": []                                                                                         // 104
        }];                                                                                                            // 103
        return proceedQueryExecution(methodArray, true, sessionId);                                                    // 107
    },                                                                                                                 // 108
    serverInfo: function (sessionId) {                                                                                 // 110
        var methodArray = [{                                                                                           // 111
            "serverInfo": []                                                                                           // 113
        }];                                                                                                            // 112
        return proceedQueryExecution(methodArray, true, sessionId);                                                    // 116
    },                                                                                                                 // 117
    replSetGetStatus: function (sessionId) {                                                                           // 119
        var methodArray = [{                                                                                           // 120
            "replSetGetStatus": []                                                                                     // 122
        }];                                                                                                            // 121
        return proceedQueryExecution(methodArray, true, sessionId);                                                    // 125
    },                                                                                                                 // 126
    removeUser: function (username, runOnAdminDB, sessionId) {                                                         // 128
        var methodArray = [{                                                                                           // 129
            "removeUser": [username]                                                                                   // 131
        }];                                                                                                            // 130
        return proceedQueryExecution(methodArray, runOnAdminDB, sessionId);                                            // 134
    },                                                                                                                 // 135
    profilingInfo: function (sessionId) {                                                                              // 137
        var methodArray = [{                                                                                           // 138
            "profilingInfo": []                                                                                        // 140
        }];                                                                                                            // 139
        return proceedQueryExecution(methodArray, true, sessionId);                                                    // 143
    },                                                                                                                 // 144
    ping: function (sessionId) {                                                                                       // 146
        var methodArray = [{                                                                                           // 147
            "ping": []                                                                                                 // 149
        }];                                                                                                            // 148
        return proceedQueryExecution(methodArray, true, sessionId);                                                    // 152
    },                                                                                                                 // 153
    listDatabases: function (sessionId) {                                                                              // 155
        var methodArray = [{                                                                                           // 156
            "listDatabases": []                                                                                        // 158
        }];                                                                                                            // 157
        return proceedQueryExecution(methodArray, true, sessionId);                                                    // 161
    },                                                                                                                 // 162
    command: function (command, runOnAdminDB, options, sessionId) {                                                    // 164
        var methodArray = [{                                                                                           // 165
            "command": [command, options]                                                                              // 167
        }];                                                                                                            // 166
        return proceedQueryExecution(methodArray, runOnAdminDB, sessionId);                                            // 170
    },                                                                                                                 // 171
    addUser: function (username, password, options, runOnAdminDB, sessionId) {                                         // 173
        var methodArray = [{                                                                                           // 174
            "addUser": [username, password, options]                                                                   // 176
        }];                                                                                                            // 175
        return proceedQueryExecution(methodArray, runOnAdminDB, sessionId);                                            // 179
    },                                                                                                                 // 180
    buildInfo: function (sessionId) {                                                                                  // 182
        var methodArray = [{                                                                                           // 183
            "buildInfo": []                                                                                            // 185
        }];                                                                                                            // 184
        return proceedQueryExecution(methodArray, true, sessionId);                                                    // 188
    }                                                                                                                  // 189
});                                                                                                                    // 46
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods_collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/mongodb/methods_collection.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
    proceedQueryExecution: function () {                                                                               // 1
        return proceedQueryExecution;                                                                                  // 1
    }                                                                                                                  // 1
});                                                                                                                    // 1
var LOGGER = void 0;                                                                                                   // 1
module.watch(require("../internal/logger"), {                                                                          // 1
    "default": function (v) {                                                                                          // 1
        LOGGER = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var Helper = void 0;                                                                                                   // 1
module.watch(require("./helper"), {                                                                                    // 1
    "default": function (v) {                                                                                          // 1
        Helper = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var Meteor = void 0;                                                                                                   // 1
module.watch(require("meteor/meteor"), {                                                                               // 1
    Meteor: function (v) {                                                                                             // 1
        Meteor = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var databasesBySessionId = void 0;                                                                                     // 1
module.watch(require("./methods_common"), {                                                                            // 1
    databasesBySessionId: function (v) {                                                                               // 1
        databasesBySessionId = v;                                                                                      // 1
    }                                                                                                                  // 1
}, 3);                                                                                                                 // 1
                                                                                                                       //
var proceedMapReduceExecution = function (selectedCollection, map, reduce, options, sessionId) {                       // 11
    options = Helper.convertJSONtoBSON(options);                                                                       // 12
    LOGGER.info('[mapReduce]', selectedCollection, map, reduce, options, sessionId);                                   // 14
    var result = Async.runSync(function (done) {                                                                       // 16
        try {                                                                                                          // 17
            var collection = databasesBySessionId[sessionId].collection(selectedCollection);                           // 18
            collection.mapReduce(map, reduce, options, function (err, resultCollection) {                              // 19
                if (err) {                                                                                             // 20
                    done(err, null);                                                                                   // 21
                    return;                                                                                            // 22
                }                                                                                                      // 23
                                                                                                                       //
                if (typeof options.out === 'string') {                                                                 // 24
                    resultCollection.find().toArray(function (err, result) {                                           // 25
                        done(err, result);                                                                             // 26
                    });                                                                                                // 27
                } else {                                                                                               // 28
                    done(err, resultCollection);                                                                       // 30
                }                                                                                                      // 31
            });                                                                                                        // 32
        } catch (ex) {                                                                                                 // 33
            LOGGER.error('[mapReduce]', sessionId, ex);                                                                // 35
            done(new Meteor.Error(ex.message), null);                                                                  // 36
        }                                                                                                              // 37
    });                                                                                                                // 38
    return Helper.convertBSONtoJSON(result);                                                                           // 40
};                                                                                                                     // 41
                                                                                                                       //
var proceedQueryExecution = function (selectedCollection, methodArray, sessionId, removeCollectionTopology) {          // 43
    LOGGER.info(JSON.stringify(methodArray), selectedCollection, sessionId);                                           // 44
    var result = Async.runSync(function (done) {                                                                       // 46
        try {                                                                                                          // 47
            var execution = databasesBySessionId[sessionId].collection(selectedCollection);                            // 48
                                                                                                                       //
            for (var i = 0; i < methodArray.length; i++) {                                                             // 49
                var last = i === methodArray.length - 1;                                                               // 50
                var entry = methodArray[i];                                                                            // 51
                entry = Helper.convertJSONtoBSON(entry);                                                               // 52
                                                                                                                       //
                for (var key in meteorBabelHelpers.sanitizeForInObject(entry)) {                                       // 53
                    if (entry.hasOwnProperty(key)) {                                                                   // 54
                        if (last && key === Object.keys(entry)[Object.keys(entry).length - 1]) {                       // 55
                            entry[key].push(function (err, docs) {                                                     // 56
                                done(err, docs);                                                                       // 57
                            });                                                                                        // 58
                            execution[key].apply(execution, entry[key]);                                               // 60
                        } else {                                                                                       // 61
                            execution = execution[key].apply(execution, entry[key]);                                   // 63
                        }                                                                                              // 64
                    }                                                                                                  // 65
                }                                                                                                      // 66
            }                                                                                                          // 67
        } catch (ex) {                                                                                                 // 68
            LOGGER.error(methodArray, sessionId, ex);                                                                  // 70
            done(new Meteor.Error(ex.message), null);                                                                  // 71
        }                                                                                                              // 72
    });                                                                                                                // 73
                                                                                                                       //
    if (removeCollectionTopology) {                                                                                    // 75
        Helper.removeCollectionTopology(result);                                                                       // 76
    }                                                                                                                  // 77
                                                                                                                       //
    Helper.removeConnectionTopology(result);                                                                           // 78
    return Helper.convertBSONtoJSON(result);                                                                           // 79
};                                                                                                                     // 80
                                                                                                                       //
Meteor.methods({                                                                                                       // 82
    saveFindResult: function (selectedCollection, updateObjects, deleteObjectIds, addedObjects, sessionId) {           // 83
        for (var _iterator = updateObjects, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
            var _ref;                                                                                                  // 84
                                                                                                                       //
            if (_isArray) {                                                                                            // 84
                if (_i >= _iterator.length) break;                                                                     // 84
                _ref = _iterator[_i++];                                                                                // 84
            } else {                                                                                                   // 84
                _i = _iterator.next();                                                                                 // 84
                if (_i.done) break;                                                                                    // 84
                _ref = _i.value;                                                                                       // 84
            }                                                                                                          // 84
                                                                                                                       //
            var obj = _ref;                                                                                            // 84
            proceedQueryExecution(selectedCollection, [{                                                               // 85
                "updateOne": [{                                                                                        // 85
                    _id: obj._id                                                                                       // 85
                }, obj, {}]                                                                                            // 85
            }], sessionId);                                                                                            // 85
        }                                                                                                              // 86
                                                                                                                       //
        if (deleteObjectIds.length > 0) {                                                                              // 88
            proceedQueryExecution(selectedCollection, [{                                                               // 89
                "deleteMany": [{                                                                                       // 89
                    _id: {                                                                                             // 89
                        $in: deleteObjectIds                                                                           // 89
                    }                                                                                                  // 89
                }]                                                                                                     // 89
            }], sessionId);                                                                                            // 89
        }                                                                                                              // 90
                                                                                                                       //
        if (addedObjects.length > 0) {                                                                                 // 92
            proceedQueryExecution(selectedCollection, [{                                                               // 93
                "insertMany": [addedObjects]                                                                           // 93
            }], sessionId);                                                                                            // 93
        }                                                                                                              // 94
    },                                                                                                                 // 95
    bulkWrite: function (selectedCollection, operations, options, sessionId) {                                         // 97
        var methodArray = [{                                                                                           // 98
            "bulkWrite": [operations, options]                                                                         // 100
        }];                                                                                                            // 99
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 103
    },                                                                                                                 // 104
    updateOne: function (selectedCollection, selector, setObject, options, sessionId) {                                // 106
        var methodArray = [{                                                                                           // 107
            "updateOne": [selector, setObject, options]                                                                // 109
        }];                                                                                                            // 108
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 112
    },                                                                                                                 // 113
    updateMany: function (selectedCollection, selector, setObject, options, sessionId) {                               // 115
        var methodArray = [{                                                                                           // 116
            "updateMany": [selector, setObject, options]                                                               // 118
        }];                                                                                                            // 117
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 121
    },                                                                                                                 // 122
    stats: function (selectedCollection, options, sessionId) {                                                         // 124
        var methodArray = [{                                                                                           // 125
            "stats": [options]                                                                                         // 127
        }];                                                                                                            // 126
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 130
    },                                                                                                                 // 131
    rename: function (selectedCollection, newName, options, sessionId) {                                               // 133
        var methodArray = [{                                                                                           // 134
            "rename": [newName, options]                                                                               // 136
        }];                                                                                                            // 135
        return proceedQueryExecution(selectedCollection, methodArray, sessionId, true);                                // 140
    },                                                                                                                 // 141
    reIndex: function (selectedCollection, sessionId) {                                                                // 143
        var methodArray = [{                                                                                           // 144
            "reIndex": []                                                                                              // 146
        }];                                                                                                            // 145
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 149
    },                                                                                                                 // 150
    options: function (selectedCollection, sessionId) {                                                                // 152
        var methodArray = [{                                                                                           // 153
            "options": []                                                                                              // 155
        }];                                                                                                            // 154
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 158
    },                                                                                                                 // 159
    mapReduce: function (selectedCollection, map, reduce, options, sessionId) {                                        // 161
        return proceedMapReduceExecution(selectedCollection, map, reduce, options, sessionId);                         // 162
    },                                                                                                                 // 163
    isCapped: function (selectedCollection, sessionId) {                                                               // 165
        var methodArray = [{                                                                                           // 166
            "isCapped": []                                                                                             // 168
        }];                                                                                                            // 167
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 171
    },                                                                                                                 // 172
    insertMany: function (selectedCollection, docs, options, sessionId) {                                              // 174
        var methodArray = [{                                                                                           // 175
            "insertMany": [docs, options]                                                                              // 177
        }];                                                                                                            // 176
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 180
    },                                                                                                                 // 181
    indexInformation: function (selectedCollection, isFull, sessionId) {                                               // 183
        var methodArray = [{                                                                                           // 184
            "indexInformation": [{                                                                                     // 186
                'full': isFull                                                                                         // 186
            }]                                                                                                         // 186
        }];                                                                                                            // 185
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 189
    },                                                                                                                 // 190
    geoNear: function (selectedCollection, xAxis, yAxis, options, sessionId) {                                         // 192
        var methodArray = [{                                                                                           // 193
            "geoNear": [xAxis, yAxis, options]                                                                         // 195
        }];                                                                                                            // 194
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 198
    },                                                                                                                 // 199
    geoHaystackSearch: function (selectedCollection, xAxis, yAxis, options, sessionId) {                               // 201
        var methodArray = [{                                                                                           // 202
            "geoHaystackSearch": [xAxis, yAxis, options]                                                               // 204
        }];                                                                                                            // 203
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 207
    },                                                                                                                 // 208
    dropIndex: function (selectedCollection, indexName, sessionId) {                                                   // 210
        var methodArray = [{                                                                                           // 211
            "dropIndex": [indexName]                                                                                   // 213
        }];                                                                                                            // 212
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 217
    },                                                                                                                 // 218
    distinct: function (selectedCollection, selector, fieldName, options, sessionId) {                                 // 220
        var methodArray = [{                                                                                           // 221
            "distinct": [fieldName, selector, options]                                                                 // 223
        }];                                                                                                            // 222
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 227
    },                                                                                                                 // 228
    "delete": function (selectedCollection, selector, sessionId) {                                                     // 82
        var methodArray = [{                                                                                           // 231
            "deleteMany": [selector]                                                                                   // 233
        }];                                                                                                            // 232
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 237
    },                                                                                                                 // 238
    createIndex: function (selectedCollection, fields, options, sessionId) {                                           // 240
        var methodArray = [{                                                                                           // 241
            "createIndex": [fields, options]                                                                           // 243
        }];                                                                                                            // 242
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 247
    },                                                                                                                 // 248
    findOne: function (selectedCollection, selector, cursorOptions, sessionId) {                                       // 250
        var methodArray = [{                                                                                           // 251
            "find": [selector]                                                                                         // 253
        }];                                                                                                            // 252
                                                                                                                       //
        for (var key in meteorBabelHelpers.sanitizeForInObject(cursorOptions)) {                                       // 256
            if (cursorOptions.hasOwnProperty(key) && cursorOptions[key]) {                                             // 257
                var obj = {};                                                                                          // 258
                obj[key] = [cursorOptions[key]];                                                                       // 259
                methodArray.push(obj);                                                                                 // 260
            }                                                                                                          // 261
        }                                                                                                              // 262
                                                                                                                       //
        methodArray.push({                                                                                             // 263
            'limit': [1]                                                                                               // 263
        });                                                                                                            // 263
        methodArray.push({                                                                                             // 264
            'next': []                                                                                                 // 264
        });                                                                                                            // 264
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 265
    },                                                                                                                 // 266
    find: function (selectedCollection, selector, cursorOptions, executeExplain, sessionId) {                          // 268
        var methodArray = [{                                                                                           // 269
            "find": [selector]                                                                                         // 271
        }];                                                                                                            // 270
                                                                                                                       //
        for (var key in meteorBabelHelpers.sanitizeForInObject(cursorOptions)) {                                       // 274
            if (cursorOptions.hasOwnProperty(key) && cursorOptions[key]) {                                             // 275
                var obj = {};                                                                                          // 276
                obj[key] = [cursorOptions[key]];                                                                       // 277
                methodArray.push(obj);                                                                                 // 278
            }                                                                                                          // 279
        }                                                                                                              // 280
                                                                                                                       //
        if (executeExplain) {                                                                                          // 282
            methodArray.push({                                                                                         // 283
                'explain': []                                                                                          // 283
            });                                                                                                        // 283
        } else {                                                                                                       // 284
            methodArray.push({                                                                                         // 285
                'toArray': []                                                                                          // 285
            });                                                                                                        // 285
        }                                                                                                              // 286
                                                                                                                       //
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 288
    },                                                                                                                 // 289
    findOneAndUpdate: function (selectedCollection, selector, setObject, options, sessionId) {                         // 291
        var methodArray = [{                                                                                           // 292
            "findOneAndUpdate": [selector, setObject, options]                                                         // 294
        }];                                                                                                            // 293
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 297
    },                                                                                                                 // 298
    findOneAndReplace: function (selectedCollection, selector, setObject, options, sessionId) {                        // 300
        var methodArray = [{                                                                                           // 301
            "findOneAndReplace": [selector, setObject, options]                                                        // 303
        }];                                                                                                            // 302
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 306
    },                                                                                                                 // 307
    findOneAndDelete: function (selectedCollection, selector, options, sessionId) {                                    // 309
        var methodArray = [{                                                                                           // 310
            "findOneAndDelete": [selector, options]                                                                    // 312
        }];                                                                                                            // 311
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 315
    },                                                                                                                 // 316
    aggregate: function (selectedCollection, pipeline) {                                                               // 318
        var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};                          // 318
        var sessionId = arguments[3];                                                                                  // 318
        var methodArray = [{                                                                                           // 319
            "aggregate": [pipeline, options]                                                                           // 321
        }];                                                                                                            // 320
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 324
    },                                                                                                                 // 325
    count: function (selectedCollection, selector, options, sessionId) {                                               // 327
        var methodArray = [{                                                                                           // 328
            "count": [selector, options]                                                                               // 330
        }];                                                                                                            // 329
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 333
    },                                                                                                                 // 334
    group: function (selectedCollection, keys, condition, initial, reduce, finalize, command, sessionId) {             // 336
        var methodArray = [{                                                                                           // 337
            "group": [keys, condition, initial, reduce, finalize, command]                                             // 339
        }];                                                                                                            // 338
        return proceedQueryExecution(selectedCollection, methodArray, sessionId);                                      // 343
    }                                                                                                                  // 344
});                                                                                                                    // 82
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods_common.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/mongodb/methods_common.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
    databasesBySessionId: function () {                                                                                // 1
        return databasesBySessionId;                                                                                   // 1
    },                                                                                                                 // 1
    getProperBinary: function () {                                                                                     // 1
        return getProperBinary;                                                                                        // 1
    }                                                                                                                  // 1
});                                                                                                                    // 1
var Meteor = void 0;                                                                                                   // 1
module.watch(require("meteor/meteor"), {                                                                               // 1
    Meteor: function (v) {                                                                                             // 1
        Meteor = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var Settings = void 0,                                                                                                 // 1
    Connections = void 0,                                                                                              // 1
    Dumps = void 0,                                                                                                    // 1
    ShellCommands = void 0,                                                                                            // 1
    SchemaAnalyzeResult = void 0;                                                                                      // 1
module.watch(require("/lib/imports/collections"), {                                                                    // 1
    Settings: function (v) {                                                                                           // 1
        Settings = v;                                                                                                  // 1
    },                                                                                                                 // 1
    Connections: function (v) {                                                                                        // 1
        Connections = v;                                                                                               // 1
    },                                                                                                                 // 1
    Dumps: function (v) {                                                                                              // 1
        Dumps = v;                                                                                                     // 1
    },                                                                                                                 // 1
    ShellCommands: function (v) {                                                                                      // 1
        ShellCommands = v;                                                                                             // 1
    },                                                                                                                 // 1
    SchemaAnalyzeResult: function (v) {                                                                                // 1
        SchemaAnalyzeResult = v;                                                                                       // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var migrateConnectionsIfExist = void 0;                                                                                // 1
module.watch(require("/server/imports/internal/startup"), {                                                            // 1
    migrateConnectionsIfExist: function (v) {                                                                          // 1
        migrateConnectionsIfExist = v;                                                                                 // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var LOGGER = void 0;                                                                                                   // 1
module.watch(require("../internal/logger"), {                                                                          // 1
    "default": function (v) {                                                                                          // 1
        LOGGER = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 3);                                                                                                                 // 1
var Helper = void 0;                                                                                                   // 1
module.watch(require("./helper"), {                                                                                    // 1
    "default": function (v) {                                                                                          // 1
        Helper = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 4);                                                                                                                 // 1
                                                                                                                       //
var mongodbApi = require('mongodb');                                                                                   // 13
                                                                                                                       //
var tunnelSsh = new require('tunnel-ssh');                                                                             // 14
                                                                                                                       //
var fs = require('fs');                                                                                                // 15
                                                                                                                       //
var spawn = require('cross-spawn');                                                                                    // 16
                                                                                                                       //
var os = require('os');                                                                                                // 17
                                                                                                                       //
var databasesBySessionId = {};                                                                                         // 19
var spawnedShellsBySessionId = {};                                                                                     // 20
var tunnelsBySessionId = {};                                                                                           // 21
                                                                                                                       //
var getProperBinary = function (binaryName) {                                                                          // 23
    var settings = Settings.findOne();                                                                                 // 24
                                                                                                                       //
    if (settings.mongoBinaryPath) {                                                                                    // 25
        var dir = settings.mongoBinaryPath.replace(/\\/g, '/') + '/';                                                  // 26
        LOGGER.info('[' + binaryName + ']', 'checking dir ' + dir + ' for binary ' + binaryName);                      // 27
        var errorMessage = 'Binary ' + binaryName + ' not found in ' + (dir + binaryName) + ', please set mongo binary path from settings';
                                                                                                                       //
        switch (os.platform()) {                                                                                       // 30
            case 'win32':                                                                                              // 31
                if (!fs.existsSync(dir + binaryName + '.exe')) throw new Meteor.Error(errorMessage);                   // 32
                return dir + binaryName + '.exe';                                                                      // 33
                                                                                                                       //
            default:                                                                                                   // 34
                if (!fs.existsSync(dir + binaryName)) throw new Meteor.Error(errorMessage);                            // 35
                return dir + binaryName;                                                                               // 36
        }                                                                                                              // 30
    } else if (!settings.mongoBinaryPath && binaryName === 'mongo') {                                                  // 38
        var _dir = getMongoExternalsPath();                                                                            // 40
                                                                                                                       //
        switch (os.platform()) {                                                                                       // 41
            case 'darwin':                                                                                             // 42
                return _dir + 'darwin/mongo';                                                                          // 43
                                                                                                                       //
            case 'win32':                                                                                              // 44
                return _dir + 'win32/mongo.exe';                                                                       // 45
                                                                                                                       //
            case 'linux':                                                                                              // 46
                return _dir + 'linux/mongo';                                                                           // 47
                                                                                                                       //
            default:                                                                                                   // 48
                throw new Meteor.Error('Not supported os: ' + os.platform() + ', you can set mongo binary path from settings');
        }                                                                                                              // 41
    } else throw new Meteor.Error('Please set mongo binaries from settings');                                          // 51
};                                                                                                                     // 53
                                                                                                                       //
var connectToShell = function (connectionId, username, password, sessionId) {                                          // 55
    try {                                                                                                              // 56
        var connection = Connections.findOne({                                                                         // 57
            _id: connectionId                                                                                          // 57
        });                                                                                                            // 57
                                                                                                                       //
        if (!spawnedShellsBySessionId[sessionId]) {                                                                    // 58
            var connectionUrl = Helper.getConnectionUrl(connection, false, username, password, true);                  // 59
            var mongoPath = getProperBinary('mongo');                                                                  // 60
            LOGGER.info('[shell]', mongoPath, connectionUrl, sessionId);                                               // 61
            spawnedShellsBySessionId[sessionId] = spawn(mongoPath, [connectionUrl]);                                   // 62
            setEventsToShell(connectionId, sessionId);                                                                 // 63
        }                                                                                                              // 64
                                                                                                                       //
        if (spawnedShellsBySessionId[sessionId]) {                                                                     // 66
            LOGGER.info('[shell]', 'executing command "use ' + connection.databaseName + '" on shell', sessionId);     // 67
            spawnedShellsBySessionId[sessionId].stdin.write('use ' + connection.databaseName + '\n');                  // 68
        } else throw new Meteor.Error("Couldn't spawn shell, please check logs !");                                    // 69
                                                                                                                       //
        return 'use ' + connection.databaseName;                                                                       // 72
    } catch (ex) {                                                                                                     // 73
        spawnedShellsBySessionId[sessionId] = null;                                                                    // 75
        LOGGER.error('[shell]', sessionId, ex);                                                                        // 76
        throw new Meteor.Error(ex.message || ex);                                                                      // 77
    }                                                                                                                  // 78
};                                                                                                                     // 79
                                                                                                                       //
var keepDroppingCollections = function (collections, i, done) {                                                        // 81
    if (collections.length === 0 || i >= collections.length) {                                                         // 82
        done(null, {});                                                                                                // 83
        return;                                                                                                        // 84
    }                                                                                                                  // 85
                                                                                                                       //
    if (!collections[i].collectionName.startsWith('system')) {                                                         // 87
        collections[i].drop().then(function () {                                                                       // 88
            keepDroppingCollections(collections, ++i, done);                                                           // 89
        });                                                                                                            // 90
    } else {                                                                                                           // 91
        keepDroppingCollections(collections, ++i, done);                                                               // 93
    }                                                                                                                  // 94
};                                                                                                                     // 95
                                                                                                                       //
var getMongoExternalsPath = function () {                                                                              // 97
    var currentDir = process.cwd().replace(/\\/g, '/');                                                                // 98
    currentDir = currentDir.substring(0, currentDir.lastIndexOf("/")) + '/web.browser/app/mongo/'; // make sure everything has correct permissions
                                                                                                                       //
    fs.chmodSync(currentDir, '777');                                                                                   // 102
    fs.chmodSync(currentDir + "darwin/mongo", '777');                                                                  // 103
    fs.chmodSync(currentDir + "win32/mongo.exe", '777');                                                               // 104
    fs.chmodSync(currentDir + "linux/mongo", '777');                                                                   // 105
    fs.chmodSync(currentDir + "variety/variety.js_", '777');                                                           // 106
    return currentDir;                                                                                                 // 108
};                                                                                                                     // 109
                                                                                                                       //
var proceedConnectingMongodb = function (dbName, sessionId, connectionUrl, connectionOptions, done) {                  // 111
    if (!connectionOptions) {                                                                                          // 112
        connectionOptions = {};                                                                                        // 113
    }                                                                                                                  // 114
                                                                                                                       //
    mongodbApi.MongoClient.connect(connectionUrl, connectionOptions, function (mainError, db) {                        // 116
        try {                                                                                                          // 117
            if (mainError || !db) {                                                                                    // 118
                LOGGER.error(mainError, sessionId, db);                                                                // 119
                done(mainError, db);                                                                                   // 120
                if (db) db.close();                                                                                    // 121
                                                                                                                       //
                if (tunnelsBySessionId[sessionId]) {                                                                   // 122
                    tunnelsBySessionId[sessionId].close();                                                             // 123
                    tunnelsBySessionId[sessionId] = null;                                                              // 124
                }                                                                                                      // 125
                                                                                                                       //
                return;                                                                                                // 126
            }                                                                                                          // 127
                                                                                                                       //
            databasesBySessionId[sessionId] = db.db(dbName);                                                           // 128
            databasesBySessionId[sessionId].listCollections().toArray(function (err, collections) {                    // 129
                done(err, collections);                                                                                // 130
            });                                                                                                        // 131
            LOGGER.info('[connect]', 'current sesssion length: ' + Object.keys(databasesBySessionId).length);          // 133
        } catch (ex) {                                                                                                 // 134
            LOGGER.error('[connect]', sessionId, ex);                                                                  // 136
            done(new Meteor.Error(ex.message), null);                                                                  // 137
            if (db) db.close();                                                                                        // 138
                                                                                                                       //
            if (tunnelsBySessionId[sessionId]) {                                                                       // 139
                tunnelsBySessionId[sessionId].close();                                                                 // 140
                tunnelsBySessionId[sessionId] = null;                                                                  // 141
            }                                                                                                          // 142
        }                                                                                                              // 143
    });                                                                                                                // 144
};                                                                                                                     // 145
                                                                                                                       //
var setEventsToShell = function (connectionId, sessionId) {                                                            // 147
    LOGGER.info('[shell]', 'binding events to shell', connectionId, sessionId);                                        // 148
    spawnedShellsBySessionId[sessionId].on('error', Meteor.bindEnvironment(function (err) {                            // 150
        LOGGER.error('unexpected error on spawned shell: ' + err, sessionId);                                          // 151
        spawnedShellsBySessionId[sessionId] = null;                                                                    // 152
                                                                                                                       //
        if (err) {                                                                                                     // 153
            ShellCommands.insert({                                                                                     // 154
                'date': Date.now(),                                                                                    // 155
                'sessionId': sessionId,                                                                                // 156
                'connectionId': connectionId,                                                                          // 157
                'message': 'unexpected error ' + err.message                                                           // 158
            });                                                                                                        // 154
        }                                                                                                              // 160
    }));                                                                                                               // 161
    spawnedShellsBySessionId[sessionId].stdout.on('data', Meteor.bindEnvironment(function (data) {                     // 163
        if (data && data.toString()) {                                                                                 // 164
            ShellCommands.insert({                                                                                     // 165
                'date': Date.now(),                                                                                    // 166
                'sessionId': sessionId,                                                                                // 167
                'connectionId': connectionId,                                                                          // 168
                'message': data.toString()                                                                             // 169
            });                                                                                                        // 165
        }                                                                                                              // 171
    }));                                                                                                               // 172
    spawnedShellsBySessionId[sessionId].stderr.on('data', Meteor.bindEnvironment(function (data) {                     // 174
        if (data && data.toString()) {                                                                                 // 175
            ShellCommands.insert({                                                                                     // 176
                'date': Date.now(),                                                                                    // 177
                'sessionId': sessionId,                                                                                // 178
                'connectionId': connectionId,                                                                          // 179
                'message': data.toString()                                                                             // 180
            });                                                                                                        // 176
        }                                                                                                              // 182
    }));                                                                                                               // 183
    spawnedShellsBySessionId[sessionId].on('close', Meteor.bindEnvironment(function (code) {                           // 185
        // show ended message in codemirror                                                                            // 186
        ShellCommands.insert({                                                                                         // 187
            'date': Date.now(),                                                                                        // 188
            'connectionId': connectionId,                                                                              // 189
            'sessionId': sessionId,                                                                                    // 190
            'message': 'shell closed ' + code.toString()                                                               // 191
        });                                                                                                            // 187
        spawnedShellsBySessionId[sessionId] = null;                                                                    // 194
        Meteor.setTimeout(function () {                                                                                // 195
            // remove all for further                                                                                  // 196
            ShellCommands.remove({                                                                                     // 197
                'sessionId': sessionId                                                                                 // 197
            });                                                                                                        // 197
        }, 500);                                                                                                       // 198
    }));                                                                                                               // 199
};                                                                                                                     // 200
                                                                                                                       //
Meteor.methods({                                                                                                       // 202
    importMongoclient: function (file) {                                                                               // 203
        LOGGER.info('[importNosqlclient]', file);                                                                      // 204
                                                                                                                       //
        try {                                                                                                          // 206
            var mongoclientData = JSON.parse(file);                                                                    // 207
                                                                                                                       //
            if (mongoclientData.settings) {                                                                            // 208
                Settings.remove({});                                                                                   // 209
                delete mongoclientData.settings._id;                                                                   // 210
                Settings.insert(mongoclientData.settings);                                                             // 211
            }                                                                                                          // 212
                                                                                                                       //
            if (mongoclientData.connections) {                                                                         // 214
                for (var i = 0; i < mongoclientData.connections.length; i++) {                                         // 215
                    delete mongoclientData.connections[i]._id;                                                         // 216
                                                                                                                       //
                    Connections._collection.insert(mongoclientData.connections[i]);                                    // 217
                }                                                                                                      // 218
                                                                                                                       //
                migrateConnectionsIfExist();                                                                           // 219
            }                                                                                                          // 220
        } catch (ex) {                                                                                                 // 221
            LOGGER.error('[importNosqlclient]', 'unexpected error during import', ex);                                 // 223
            throw new Meteor.Error(ex.message);                                                                        // 224
        }                                                                                                              // 225
    },                                                                                                                 // 226
    listCollectionNames: function (dbName, sessionId) {                                                                // 228
        LOGGER.info('[listCollectionNames]', dbName, sessionId);                                                       // 229
        return Async.runSync(function (done) {                                                                         // 231
            try {                                                                                                      // 232
                var wishedDB = databasesBySessionId[sessionId].db(dbName);                                             // 233
                wishedDB.listCollections().toArray(function (err, collections) {                                       // 234
                    done(err, collections);                                                                            // 235
                });                                                                                                    // 236
            } catch (ex) {                                                                                             // 237
                LOGGER.error('[listCollectionNames]', sessionId, ex);                                                  // 239
                done(new Meteor.Error(ex.message), null);                                                              // 240
            }                                                                                                          // 241
        });                                                                                                            // 242
    },                                                                                                                 // 244
    getDatabases: function (sessionId) {                                                                               // 246
        LOGGER.info('[getDatabases]', sessionId);                                                                      // 247
        return Async.runSync(function (done) {                                                                         // 249
            try {                                                                                                      // 250
                databasesBySessionId[sessionId].admin().listDatabases(function (err, dbs) {                            // 251
                    if (dbs) {                                                                                         // 252
                        done(err, dbs.databases);                                                                      // 253
                    } else {                                                                                           // 254
                        done(err, {});                                                                                 // 256
                    }                                                                                                  // 257
                });                                                                                                    // 258
            } catch (ex) {                                                                                             // 259
                LOGGER.error('[getDatabases]', sessionId, ex);                                                         // 261
                done(new Meteor.Error(ex.message), null);                                                              // 262
            }                                                                                                          // 263
        });                                                                                                            // 264
    },                                                                                                                 // 265
    disconnect: function (sessionId) {                                                                                 // 267
        LOGGER.info('[disconnect]', sessionId);                                                                        // 268
                                                                                                                       //
        if (databasesBySessionId[sessionId]) {                                                                         // 270
            databasesBySessionId[sessionId].close();                                                                   // 271
        }                                                                                                              // 272
                                                                                                                       //
        if (spawnedShellsBySessionId[sessionId]) {                                                                     // 273
            spawnedShellsBySessionId[sessionId].stdin.end();                                                           // 274
            spawnedShellsBySessionId[sessionId] = null;                                                                // 275
        }                                                                                                              // 276
                                                                                                                       //
        ShellCommands.remove({                                                                                         // 277
            'sessionId': sessionId                                                                                     // 277
        });                                                                                                            // 277
        SchemaAnalyzeResult.remove({                                                                                   // 278
            'sessionId': sessionId                                                                                     // 278
        });                                                                                                            // 278
        Dumps.remove({                                                                                                 // 279
            'sessionId': sessionId                                                                                     // 279
        });                                                                                                            // 279
    },                                                                                                                 // 280
    connect: function (connectionId, username, password, sessionId) {                                                  // 282
        var connection = Connections.findOne({                                                                         // 283
            _id: connectionId                                                                                          // 283
        });                                                                                                            // 283
        var connectionUrl = Helper.getConnectionUrl(connection, false, username, password);                            // 284
        var connectionOptions = Helper.getConnectionOptions(connection);                                               // 285
        LOGGER.info('[connect]', connectionUrl, Helper.clearConnectionOptionsForLog(connectionOptions), sessionId);    // 287
        return Async.runSync(function (done) {                                                                         // 289
            try {                                                                                                      // 290
                if (connection.ssh && connection.ssh.enabled) {                                                        // 291
                    var config = {                                                                                     // 292
                        dstPort: connection.ssh.destinationPort,                                                       // 293
                        localPort: connection.ssh.localPort ? connection.ssh.localPort : connection.servers[0].port,   // 294
                        host: connection.ssh.host,                                                                     // 295
                        port: connection.ssh.port,                                                                     // 296
                        readyTimeout: 99999,                                                                           // 297
                        username: connection.ssh.username                                                              // 298
                    };                                                                                                 // 292
                    if (connection.ssh.certificateFile) config.privateKey = new Buffer(connection.ssh.certificateFile);
                    if (connection.ssh.passPhrase) config.passphrase = connection.ssh.passPhrase;                      // 302
                    if (connection.ssh.password) config.password = connection.ssh.password;                            // 303
                    LOGGER.info('[connect]', '[ssh]', sessionId, 'ssh is enabled, config is ' + JSON.stringify(config));
                    tunnelsBySessionId[sessionId] = tunnelSsh(config, Meteor.bindEnvironment(function (error) {        // 306
                        if (error) {                                                                                   // 307
                            done(new Meteor.Error(error.message), null);                                               // 308
                            return;                                                                                    // 309
                        }                                                                                              // 310
                                                                                                                       //
                        proceedConnectingMongodb(connection.databaseName, sessionId, connectionUrl, connectionOptions, done);
                        var mongoPath = getProperBinary('mongo');                                                      // 313
                        spawnedShellsBySessionId[sessionId] = spawn(mongoPath, [connectionUrl]);                       // 314
                        setEventsToShell(connectionId, sessionId);                                                     // 315
                    }));                                                                                               // 316
                    tunnelsBySessionId[sessionId].on('error', function (err) {                                         // 318
                        if (err) done(new Meteor.Error(err.message), null);                                            // 319
                                                                                                                       //
                        if (tunnelsBySessionId[sessionId]) {                                                           // 320
                            tunnelsBySessionId[sessionId].close();                                                     // 321
                            tunnelsBySessionId[sessionId] = null;                                                      // 322
                        }                                                                                              // 323
                    });                                                                                                // 324
                } else {                                                                                               // 325
                    proceedConnectingMongodb(connection.databaseName, sessionId, connectionUrl, connectionOptions, done);
                }                                                                                                      // 328
            } catch (ex) {                                                                                             // 329
                LOGGER.error('[connect]', sessionId, ex);                                                              // 331
                done(new Meteor.Error(ex.message), null);                                                              // 332
            }                                                                                                          // 333
        });                                                                                                            // 334
    },                                                                                                                 // 335
    dropDB: function (sessionId) {                                                                                     // 337
        LOGGER.info('[dropDatabase]', sessionId);                                                                      // 338
        return Async.runSync(function (done) {                                                                         // 340
            try {                                                                                                      // 341
                databasesBySessionId[sessionId].dropDatabase(function (err, result) {                                  // 342
                    done(err, result);                                                                                 // 343
                });                                                                                                    // 344
            } catch (ex) {                                                                                             // 345
                LOGGER.error('[dropDatabase]', sessionId, ex);                                                         // 347
                done(new Meteor.Error(ex.message), null);                                                              // 348
            }                                                                                                          // 349
        });                                                                                                            // 350
    },                                                                                                                 // 351
    dropCollection: function (collectionName, sessionId) {                                                             // 353
        LOGGER.info('[dropCollection]', sessionId, collectionName);                                                    // 354
        return Async.runSync(function (done) {                                                                         // 356
            try {                                                                                                      // 357
                var collection = databasesBySessionId[sessionId].collection(collectionName);                           // 358
                collection.drop(function (dropError) {                                                                 // 359
                    done(dropError, null);                                                                             // 360
                });                                                                                                    // 361
            } catch (ex) {                                                                                             // 362
                LOGGER.error('[dropCollection]', sessionId, ex);                                                       // 364
                done(new Meteor.Error(ex.message), null);                                                              // 365
            }                                                                                                          // 366
        });                                                                                                            // 367
    },                                                                                                                 // 368
    dropAllCollections: function (sessionId) {                                                                         // 370
        LOGGER.info('[dropAllCollections]', sessionId);                                                                // 371
        return Async.runSync(function (done) {                                                                         // 372
            try {                                                                                                      // 373
                databasesBySessionId[sessionId].collections(function (err, collections) {                              // 374
                    keepDroppingCollections(collections, 0, done);                                                     // 375
                });                                                                                                    // 376
            } catch (ex) {                                                                                             // 377
                LOGGER.error('[dropAllCollections]', sessionId, ex);                                                   // 379
                done(new Meteor.Error(ex.message), null);                                                              // 380
            }                                                                                                          // 381
        });                                                                                                            // 382
    },                                                                                                                 // 383
    createCollection: function (collectionName, options, sessionId) {                                                  // 385
        LOGGER.info('[createCollection]', collectionName, sessionId, JSON.stringify(options));                         // 386
        return Async.runSync(function (done) {                                                                         // 388
            try {                                                                                                      // 389
                databasesBySessionId[sessionId].createCollection(collectionName, options, function (err) {             // 390
                    done(err, null);                                                                                   // 391
                });                                                                                                    // 392
            } catch (ex) {                                                                                             // 393
                LOGGER.error('[createCollection]', sessionId, ex);                                                     // 395
                done(new Meteor.Error(ex.message), null);                                                              // 396
            }                                                                                                          // 397
        });                                                                                                            // 398
    },                                                                                                                 // 399
    clearShell: function (sessionId) {                                                                                 // 401
        LOGGER.info('[clearShell]', sessionId);                                                                        // 402
        ShellCommands.remove({                                                                                         // 403
            'sessionId': sessionId                                                                                     // 403
        });                                                                                                            // 403
    },                                                                                                                 // 404
    executeShellCommand: function (command, connectionId, username, password, sessionId) {                             // 406
        LOGGER.info('[shellCommand]', sessionId, command, connectionId);                                               // 407
        if (!spawnedShellsBySessionId[sessionId]) connectToShell(connectionId, username, password, sessionId);         // 408
        if (spawnedShellsBySessionId[sessionId]) spawnedShellsBySessionId[sessionId].stdin.write(command + '\n');      // 409
    },                                                                                                                 // 410
    connectToShell: function (connectionId, username, password, sessionId) {                                           // 412
        return connectToShell(connectionId, username, password, sessionId);                                            // 413
    },                                                                                                                 // 414
    analyzeSchema: function (connectionId, username, password, collection, sessionId) {                                // 416
        var connectionUrl = Helper.getConnectionUrl(Connections.findOne({                                              // 417
            _id: connectionId                                                                                          // 417
        }), true, username, password, true);                                                                           // 417
        var mongoPath = getProperBinary('mongo');                                                                      // 418
        var args = [connectionUrl, '--quiet', '--eval', 'var collection =\"' + collection + '\", outputFormat=\"json\"', getMongoExternalsPath() + '/variety/variety.js_'];
        LOGGER.info('[analyzeSchema]', sessionId, args, collection);                                                   // 421
                                                                                                                       //
        try {                                                                                                          // 422
            var spawned = spawn(mongoPath, args);                                                                      // 423
            var message = "";                                                                                          // 424
            spawned.stdout.on('data', Meteor.bindEnvironment(function (data) {                                         // 425
                if (data.toString()) {                                                                                 // 426
                    message += data.toString();                                                                        // 427
                }                                                                                                      // 428
            }));                                                                                                       // 429
            spawned.stderr.on('data', Meteor.bindEnvironment(function (data) {                                         // 431
                if (data.toString()) {                                                                                 // 432
                    SchemaAnalyzeResult.insert({                                                                       // 433
                        'date': Date.now(),                                                                            // 434
                        'sessionId': sessionId,                                                                        // 435
                        'connectionId': connectionId,                                                                  // 436
                        'message': data.toString()                                                                     // 437
                    });                                                                                                // 433
                }                                                                                                      // 439
            }));                                                                                                       // 440
            spawned.on('close', Meteor.bindEnvironment(function () {                                                   // 442
                SchemaAnalyzeResult.insert({                                                                           // 443
                    'date': Date.now(),                                                                                // 444
                    'sessionId': sessionId,                                                                            // 445
                    'connectionId': connectionId,                                                                      // 446
                    'message': message                                                                                 // 447
                });                                                                                                    // 443
            }));                                                                                                       // 449
            spawned.stdin.end();                                                                                       // 451
        } catch (ex) {                                                                                                 // 452
            LOGGER.error('[analyzeSchema]', sessionId, ex);                                                            // 454
            throw new Meteor.Error(ex.message);                                                                        // 455
        }                                                                                                              // 456
    }                                                                                                                  // 458
});                                                                                                                    // 202
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods_dump_restore.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/mongodb/methods_dump_restore.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.watch(require("meteor/meteor"), {                                                                               // 1
    Meteor: function (v) {                                                                                             // 1
        Meteor = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var Dumps = void 0;                                                                                                    // 1
module.watch(require("/lib/imports/collections"), {                                                                    // 1
    Dumps: function (v) {                                                                                              // 1
        Dumps = v;                                                                                                     // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var getProperBinary = void 0;                                                                                          // 1
module.watch(require("./methods_common"), {                                                                            // 1
    getProperBinary: function (v) {                                                                                    // 1
        getProperBinary = v;                                                                                           // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var LOGGER = void 0;                                                                                                   // 1
module.watch(require("../internal/logger"), {                                                                          // 1
    "default": function (v) {                                                                                          // 1
        LOGGER = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 3);                                                                                                                 // 1
                                                                                                                       //
var spawn = require('cross-spawn');                                                                                    // 10
                                                                                                                       //
var executeBinary = function (args, sessionId, binaryName) {                                                           // 12
    LOGGER.info('[' + binaryName + ']', args, sessionId);                                                              // 13
    var binaryPath = getProperBinary(binaryName);                                                                      // 14
                                                                                                                       //
    try {                                                                                                              // 16
        var spawned = spawn(binaryPath, args);                                                                         // 17
        spawned.stdout.on('data', Meteor.bindEnvironment(function (data) {                                             // 18
            if (data.toString()) {                                                                                     // 19
                Dumps.insert({                                                                                         // 20
                    'date': Date.now(),                                                                                // 21
                    'sessionId': sessionId,                                                                            // 22
                    'binary': binaryName,                                                                              // 23
                    'message': data.toString()                                                                         // 24
                });                                                                                                    // 20
            }                                                                                                          // 26
        }));                                                                                                           // 27
        spawned.stderr.on('data', Meteor.bindEnvironment(function (data) {                                             // 29
            if (data.toString()) {                                                                                     // 30
                Dumps.insert({                                                                                         // 31
                    'date': Date.now(),                                                                                // 32
                    'sessionId': sessionId,                                                                            // 33
                    'binary': binaryName,                                                                              // 34
                    'message': data.toString(),                                                                        // 35
                    'error': true                                                                                      // 36
                });                                                                                                    // 31
            }                                                                                                          // 38
        }));                                                                                                           // 39
        spawned.on('close', Meteor.bindEnvironment(function () {                                                       // 41
            Dumps.insert({                                                                                             // 42
                'date': Date.now(),                                                                                    // 43
                'sessionId': sessionId,                                                                                // 44
                'binary': binaryName,                                                                                  // 45
                'message': 'CLOSED'                                                                                    // 46
            });                                                                                                        // 42
        }));                                                                                                           // 48
        spawned.stdin.end();                                                                                           // 50
    } catch (ex) {                                                                                                     // 51
        LOGGER.error('[' + binaryName + ']', sessionId, ex);                                                           // 53
        throw new Meteor.Error(ex.message || ex);                                                                      // 54
    }                                                                                                                  // 55
};                                                                                                                     // 56
                                                                                                                       //
Meteor.methods({                                                                                                       // 58
    mongodump: function (args, sessionId) {                                                                            // 59
        executeBinary(args, sessionId, 'mongodump');                                                                   // 60
    },                                                                                                                 // 61
    mongorestore: function (args, sessionId) {                                                                         // 63
        executeBinary(args, sessionId, 'mongorestore');                                                                // 64
    },                                                                                                                 // 65
    mongoexport: function (args, sessionId) {                                                                          // 67
        executeBinary(args, sessionId, 'mongoexport');                                                                 // 68
    },                                                                                                                 // 69
    mongoimport: function (args, sessionId) {                                                                          // 71
        executeBinary(args, sessionId, 'mongoimport');                                                                 // 72
    },                                                                                                                 // 73
    removeDumpLogs: function (sessionId, binary) {                                                                     // 75
        LOGGER.info('[removeDumpLogs]', sessionId, binary);                                                            // 76
        if (!binary) Dumps.remove({                                                                                    // 77
            sessionId: sessionId                                                                                       // 77
        });else Dumps.remove({                                                                                         // 77
            sessionId: sessionId,                                                                                      // 78
            binary: binary                                                                                             // 78
        });                                                                                                            // 78
    }                                                                                                                  // 79
});                                                                                                                    // 58
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods_gridfs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/mongodb/methods_gridfs.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var LOGGER = void 0;                                                                                                   // 1
module.watch(require("../internal/logger"), {                                                                          // 1
    "default": function (v) {                                                                                          // 1
        LOGGER = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var Helper = void 0;                                                                                                   // 1
module.watch(require("./helper"), {                                                                                    // 1
    "default": function (v) {                                                                                          // 1
        Helper = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var databasesBySessionId = void 0;                                                                                     // 1
module.watch(require("./methods_common"), {                                                                            // 1
    databasesBySessionId: function (v) {                                                                               // 1
        databasesBySessionId = v;                                                                                      // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var Meteor = void 0;                                                                                                   // 1
module.watch(require("meteor/meteor"), {                                                                               // 1
    Meteor: function (v) {                                                                                             // 1
        Meteor = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 3);                                                                                                                 // 1
                                                                                                                       //
var mongodbApi = require('mongodb');                                                                                   // 10
                                                                                                                       //
Meteor.methods({                                                                                                       // 12
    deleteFiles: function (bucketName, selector, sessionId) {                                                          // 13
        LOGGER.info('[deleteFiles]', bucketName, selector, sessionId);                                                 // 14
        selector = Helper.convertJSONtoBSON(selector);                                                                 // 16
        var result = Async.runSync(function (done) {                                                                   // 18
            try {                                                                                                      // 19
                var filesCollection = databasesBySessionId[sessionId].collection(bucketName + ".files");               // 20
                var chunksCollection = databasesBySessionId[sessionId].collection(bucketName + ".chunks");             // 21
                filesCollection.find(selector, {                                                                       // 23
                    _id: 1                                                                                             // 23
                }).toArray(function (err, docs) {                                                                      // 23
                    if (err) {                                                                                         // 24
                        done(err, docs);                                                                               // 25
                        return;                                                                                        // 26
                    }                                                                                                  // 27
                                                                                                                       //
                    var ids = [];                                                                                      // 29
                                                                                                                       //
                    for (var _iterator = docs, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
                        var _ref;                                                                                      // 30
                                                                                                                       //
                        if (_isArray) {                                                                                // 30
                            if (_i >= _iterator.length) break;                                                         // 30
                            _ref = _iterator[_i++];                                                                    // 30
                        } else {                                                                                       // 30
                            _i = _iterator.next();                                                                     // 30
                            if (_i.done) break;                                                                        // 30
                            _ref = _i.value;                                                                           // 30
                        }                                                                                              // 30
                                                                                                                       //
                        var obj = _ref;                                                                                // 30
                        ids.push(obj._id);                                                                             // 31
                    }                                                                                                  // 32
                                                                                                                       //
                    LOGGER.info(JSON.stringify(selector) + " removing from " + bucketName + ".files", sessionId);      // 34
                    filesCollection.deleteMany({                                                                       // 35
                        _id: {                                                                                         // 35
                            $in: ids                                                                                   // 35
                        }                                                                                              // 35
                    }, {}, function (err) {                                                                            // 35
                        if (err) {                                                                                     // 36
                            done(err, null);                                                                           // 37
                            return;                                                                                    // 38
                        }                                                                                              // 39
                                                                                                                       //
                        LOGGER.info(JSON.stringify(selector) + " removing from " + bucketName + ".chunks", sessionId);
                        chunksCollection.deleteMany({                                                                  // 42
                            files_id: {                                                                                // 42
                                $in: ids                                                                               // 42
                            }                                                                                          // 42
                        }, function (err) {                                                                            // 42
                            done(err, null);                                                                           // 43
                        });                                                                                            // 44
                    });                                                                                                // 45
                });                                                                                                    // 46
            } catch (ex) {                                                                                             // 47
                LOGGER.error('[deleteFiles]', sessionId, ex);                                                          // 49
                done(new Meteor.Error(ex.message), null);                                                              // 50
            }                                                                                                          // 51
        });                                                                                                            // 52
        return Helper.convertBSONtoJSON(result);                                                                       // 54
    },                                                                                                                 // 55
    deleteFile: function (bucketName, fileId, sessionId) {                                                             // 57
        LOGGER.info('[deleteFile]', bucketName, fileId, sessionId);                                                    // 58
        var result = Async.runSync(function (done) {                                                                   // 60
            try {                                                                                                      // 61
                var bucket = new mongodbApi.GridFSBucket(databasesBySessionId[sessionId], {                            // 62
                    bucketName: bucketName                                                                             // 62
                });                                                                                                    // 62
                bucket.delete(new mongodbApi.ObjectId(fileId), function (err) {                                        // 63
                    done(err, null);                                                                                   // 64
                });                                                                                                    // 65
            } catch (ex) {                                                                                             // 66
                LOGGER.error('[deleteFile]', sessionId, ex);                                                           // 68
                done(new Meteor.Error(ex.message), null);                                                              // 69
            }                                                                                                          // 70
        });                                                                                                            // 71
        return Helper.convertBSONtoJSON(result);                                                                       // 73
    },                                                                                                                 // 74
    getFileInfos: function (bucketName, selector, limit, sessionId) {                                                  // 76
        limit = parseInt(limit) || 100;                                                                                // 77
        selector = selector || {};                                                                                     // 78
        selector = Helper.convertJSONtoBSON(selector);                                                                 // 79
        LOGGER.info('[getFileInfos]', bucketName, JSON.stringify(selector), limit, sessionId);                         // 81
        var result = Async.runSync(function (done) {                                                                   // 83
            try {                                                                                                      // 84
                var bucket = new mongodbApi.GridFSBucket(databasesBySessionId[sessionId], {                            // 85
                    bucketName: bucketName                                                                             // 85
                });                                                                                                    // 85
                bucket.find(selector, {                                                                                // 86
                    limit: limit                                                                                       // 86
                }).toArray(function (err, files) {                                                                     // 86
                    done(err, files);                                                                                  // 87
                });                                                                                                    // 88
            } catch (ex) {                                                                                             // 90
                LOGGER.error('[getFileInfos]', sessionId, ex);                                                         // 92
                done(new Meteor.Error(ex.message), null);                                                              // 93
            }                                                                                                          // 94
        });                                                                                                            // 95
        return Helper.convertBSONtoJSON(result);                                                                       // 97
    },                                                                                                                 // 98
    uploadFile: function (bucketName, blob, fileName, contentType, metaData, aliases, sessionId) {                     // 100
        if (metaData) {                                                                                                // 101
            metaData = Helper.convertJSONtoBSON(metaData);                                                             // 102
        }                                                                                                              // 103
                                                                                                                       //
        blob = new Buffer(blob);                                                                                       // 105
        LOGGER.info('[uploadFile]', bucketName, fileName, contentType, JSON.stringify(metaData), aliases, sessionId);  // 107
        return Async.runSync(function (done) {                                                                         // 109
            try {                                                                                                      // 110
                var bucket = new mongodbApi.GridFSBucket(databasesBySessionId[sessionId], {                            // 111
                    bucketName: bucketName                                                                             // 111
                });                                                                                                    // 111
                var uploadStream = bucket.openUploadStream(fileName, {                                                 // 112
                    metadata: metaData,                                                                                // 113
                    contentType: contentType,                                                                          // 114
                    aliases: aliases                                                                                   // 115
                });                                                                                                    // 112
                uploadStream.end(blob);                                                                                // 117
                uploadStream.once('finish', function () {                                                              // 118
                    done(null, null);                                                                                  // 119
                });                                                                                                    // 120
            } catch (ex) {                                                                                             // 121
                LOGGER.error('[uploadFile]', sessionId, ex);                                                           // 123
                done(new Meteor.Error(ex.message), null);                                                              // 124
            }                                                                                                          // 125
        });                                                                                                            // 126
    },                                                                                                                 // 127
    getFile: function (bucketName, fileId, sessionId) {                                                                // 129
        LOGGER.info('[getFile]', bucketName, fileId, sessionId);                                                       // 130
        var result = Async.runSync(function (done) {                                                                   // 132
            try {                                                                                                      // 133
                var filesCollection = databasesBySessionId[sessionId].collection(bucketName + '.files');               // 134
                filesCollection.find({                                                                                 // 135
                    _id: new mongodbApi.ObjectId(fileId)                                                               // 135
                }).limit(1).next(function (err, doc) {                                                                 // 135
                    if (doc) {                                                                                         // 136
                        done(null, doc);                                                                               // 137
                    } else {                                                                                           // 138
                        done(new Meteor.Error('No file found for given ID'), null);                                    // 139
                    }                                                                                                  // 140
                });                                                                                                    // 141
            } catch (ex) {                                                                                             // 142
                LOGGER.error('[getFile]', sessionId, ex);                                                              // 144
                done(new Meteor.Error(ex.message), null);                                                              // 145
            }                                                                                                          // 146
        });                                                                                                            // 147
        return Helper.convertBSONtoJSON(result);                                                                       // 149
    }                                                                                                                  // 150
});                                                                                                                    // 12
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods_user_management.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/mongodb/methods_user_management.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.watch(require("meteor/meteor"), {                                                                               // 1
    Meteor: function (v) {                                                                                             // 1
        Meteor = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var Actions = void 0;                                                                                                  // 1
module.watch(require("/lib/imports/collections"), {                                                                    // 1
    Actions: function (v) {                                                                                            // 1
        Actions = v;                                                                                                   // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var LOGGER = void 0;                                                                                                   // 1
module.watch(require("../internal/logger"), {                                                                          // 1
    "default": function (v) {                                                                                          // 1
        LOGGER = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
                                                                                                                       //
var cheerio = require('cheerio');                                                                                      // 8
                                                                                                                       //
var fixHrefs = function (url, loadedUrl) {                                                                             // 10
    var hrefs = loadedUrl('a[href]'); // fix all hrefs                                                                 // 11
                                                                                                                       //
    hrefs.attr('href', function (i, href) {                                                                            // 14
        var tmpUrl = url;                                                                                              // 15
                                                                                                                       //
        while (href.indexOf('..') != -1) {                                                                             // 16
            href = href.substring(3);                                                                                  // 17
            tmpUrl = tmpUrl.substring(0, tmpUrl.lastIndexOf('/'));                                                     // 18
        }                                                                                                              // 19
                                                                                                                       //
        return tmpUrl + '/' + href;                                                                                    // 20
    });                                                                                                                // 21
    hrefs.each(function () {                                                                                           // 23
        loadedUrl(this).attr('data-clipboard-text', loadedUrl(this).attr('href'));                                     // 24
        loadedUrl(this).replaceWith(loadedUrl(this).not('.headerlink'));                                               // 25
    });                                                                                                                // 26
};                                                                                                                     // 27
                                                                                                                       //
var load = function (url) {                                                                                            // 29
    return cheerio.load(Meteor.http.get(url).content);                                                                 // 30
};                                                                                                                     // 31
                                                                                                                       //
Meteor.methods({                                                                                                       // 33
    getAllActions: function () {                                                                                       // 34
        var action = Actions.findOne();                                                                                // 35
                                                                                                                       //
        if (action && action.actionList) {                                                                             // 36
            return action.actionList;                                                                                  // 37
        }                                                                                                              // 38
                                                                                                                       //
        LOGGER.info('[crawl]', 'getAllActions');                                                                       // 40
        var url = "https://docs.mongodb.org/manual/reference/privilege-actions";                                       // 42
        var loadedUrl = load(url);                                                                                     // 43
        fixHrefs(url, loadedUrl);                                                                                      // 44
        var result = [];                                                                                               // 46
        loadedUrl("dl[class='authaction']").children('dt').each(function () {                                          // 48
            result.push(loadedUrl(this).attr('id').replace('authr.', ''));                                             // 49
        });                                                                                                            // 50
        Meteor.call('saveActions', {                                                                                   // 52
            actionList: result                                                                                         // 52
        });                                                                                                            // 52
        return result;                                                                                                 // 53
    },                                                                                                                 // 54
    getActionInfo: function (action) {                                                                                 // 56
        LOGGER.info('[crawl]', 'getAction', action);                                                                   // 57
        var url = "https://docs.mongodb.org/manual/reference/privilege-actions";                                       // 59
        var loadedUrl = load(url);                                                                                     // 60
        fixHrefs(url, loadedUrl);                                                                                      // 61
        return loadedUrl("dt[id='" + action + "']").parent('dl[class=authaction]').children('dd').html();              // 63
    },                                                                                                                 // 64
    getRoleInfo: function (roleName) {                                                                                 // 66
        LOGGER.info('[crawl]', 'getRoleInfo', roleName);                                                               // 67
        var url = "https://docs.mongodb.org/manual/reference/built-in-roles";                                          // 69
        var loadedUrl = load(url + "/#" + roleName);                                                                   // 71
        var result = 'It looks like a user-defined role';                                                              // 72
        loadedUrl('.authrole').each(function () {                                                                      // 74
            if (loadedUrl(this).children('dt').attr('id') == roleName) {                                               // 75
                fixHrefs(url, loadedUrl);                                                                              // 76
                result = loadedUrl(this).children('dd').html();                                                        // 77
            }                                                                                                          // 78
        });                                                                                                            // 79
        return result;                                                                                                 // 81
    },                                                                                                                 // 82
    getResourceInfo: function (resource) {                                                                             // 84
        LOGGER.info('[crawl]', 'getResourceInfo', resource);                                                           // 85
        var url = "https://docs.mongodb.org/manual/reference/resource-document";                                       // 87
        var loadedUrl = load(url);                                                                                     // 88
        fixHrefs(url, loadedUrl);                                                                                      // 90
                                                                                                                       //
        if (resource == 'cluster') {                                                                                   // 92
            return loadedUrl('div[id=cluster-resource]').html();                                                       // 93
        }                                                                                                              // 94
                                                                                                                       //
        if (resource == 'anyResource') {                                                                               // 96
            return loadedUrl('div[id=anyresource]').html();                                                            // 97
        }                                                                                                              // 98
                                                                                                                       //
        if (resource == 'db+collection') {                                                                             // 100
            return loadedUrl('div[id=specify-a-collection-of-a-database-as-resource]').html();                         // 101
        }                                                                                                              // 102
                                                                                                                       //
        if (resource == 'db') {                                                                                        // 104
            return loadedUrl('div[id=specify-a-database-as-resource]').html();                                         // 105
        }                                                                                                              // 106
                                                                                                                       //
        if (resource == 'collection') {                                                                                // 108
            return loadedUrl('div[id=specify-collections-across-databases-as-resource]').html();                       // 109
        }                                                                                                              // 110
                                                                                                                       //
        if (resource == 'non-system') {                                                                                // 112
            return loadedUrl('div[id=specify-all-non-system-collections-in-all-databases]').html();                    // 113
        }                                                                                                              // 114
                                                                                                                       //
        return "Couldn't find corresponding resource document in docs.mongodb.org";                                    // 116
    }                                                                                                                  // 117
});                                                                                                                    // 33
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publishers":{"publisher.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/publishers/publisher.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.watch(require("meteor/meteor"), {                                                                               // 1
    Meteor: function (v) {                                                                                             // 1
        Meteor = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var Connections = void 0,                                                                                              // 1
    Actions = void 0,                                                                                                  // 1
    Dumps = void 0,                                                                                                    // 1
    QueryHistory = void 0,                                                                                             // 1
    Settings = void 0,                                                                                                 // 1
    ShellCommands = void 0,                                                                                            // 1
    SchemaAnalyzeResult = void 0;                                                                                      // 1
module.watch(require("/lib/imports/collections"), {                                                                    // 1
    Connections: function (v) {                                                                                        // 1
        Connections = v;                                                                                               // 1
    },                                                                                                                 // 1
    Actions: function (v) {                                                                                            // 1
        Actions = v;                                                                                                   // 1
    },                                                                                                                 // 1
    Dumps: function (v) {                                                                                              // 1
        Dumps = v;                                                                                                     // 1
    },                                                                                                                 // 1
    QueryHistory: function (v) {                                                                                       // 1
        QueryHistory = v;                                                                                              // 1
    },                                                                                                                 // 1
    Settings: function (v) {                                                                                           // 1
        Settings = v;                                                                                                  // 1
    },                                                                                                                 // 1
    ShellCommands: function (v) {                                                                                      // 1
        ShellCommands = v;                                                                                             // 1
    },                                                                                                                 // 1
    SchemaAnalyzeResult: function (v) {                                                                                // 1
        SchemaAnalyzeResult = v;                                                                                       // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
Meteor.publish('schema_analyze_result', function () {                                                                  // 15
    return SchemaAnalyzeResult.find({});                                                                               // 16
});                                                                                                                    // 17
Meteor.publish('shell_commands', function () {                                                                         // 19
    return ShellCommands.find({});                                                                                     // 20
});                                                                                                                    // 21
Meteor.publish('connections', function () {                                                                            // 23
    return Connections.find();                                                                                         // 24
});                                                                                                                    // 25
Meteor.publish('actions', function () {                                                                                // 27
    return Actions.find();                                                                                             // 28
});                                                                                                                    // 29
Meteor.publish('dumps', function () {                                                                                  // 31
    return Dumps.find({}, {                                                                                            // 32
        sort: {                                                                                                        // 32
            date: 1                                                                                                    // 32
        }                                                                                                              // 32
    });                                                                                                                // 32
});                                                                                                                    // 33
Meteor.publish('queryHistories', function () {                                                                         // 35
    return QueryHistory.find();                                                                                        // 36
});                                                                                                                    // 37
Meteor.publish('settings', function () {                                                                               // 39
    return Settings.find();                                                                                            // 40
});                                                                                                                    // 41
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"webapp.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/imports/webapp.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var WebApp = void 0;                                                                                                   // 1
module.watch(require("meteor/webapp"), {                                                                               // 1
    WebApp: function (v) {                                                                                             // 1
        WebApp = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var Meteor = void 0;                                                                                                   // 1
module.watch(require("meteor/meteor"), {                                                                               // 1
    Meteor: function (v) {                                                                                             // 1
        Meteor = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var Papa = void 0;                                                                                                     // 1
module.watch(require("meteor/harrison:papa-parse"), {                                                                  // 1
    Papa: function (v) {                                                                                               // 1
        Papa = v;                                                                                                      // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var Settings = void 0,                                                                                                 // 1
    Connections = void 0;                                                                                              // 1
module.watch(require("/lib/imports/collections"), {                                                                    // 1
    Settings: function (v) {                                                                                           // 1
        Settings = v;                                                                                                  // 1
    },                                                                                                                 // 1
    Connections: function (v) {                                                                                        // 1
        Connections = v;                                                                                               // 1
    }                                                                                                                  // 1
}, 3);                                                                                                                 // 1
var databasesBySessionId = void 0;                                                                                     // 1
module.watch(require("/server/imports/mongodb/methods_common"), {                                                      // 1
    databasesBySessionId: function (v) {                                                                               // 1
        databasesBySessionId = v;                                                                                      // 1
    }                                                                                                                  // 1
}, 4);                                                                                                                 // 1
var LOGGER = void 0;                                                                                                   // 1
module.watch(require("/server/imports/internal/logger"), {                                                             // 1
    "default": function (v) {                                                                                          // 1
        LOGGER = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 5);                                                                                                                 // 1
                                                                                                                       //
var mongodbApi = require('mongodb');                                                                                   // 11
                                                                                                                       //
WebApp.connectHandlers.use('/exportMongoclient', function (req, res) {                                                 // 13
    var fileContent = {};                                                                                              // 14
    fileContent.settings = Settings.findOne();                                                                         // 15
    fileContent.connections = Connections.find().fetch();                                                              // 16
    var fileName = "backup_" + moment().format('DD_MM_YYYY_HH_mm_ss') + ".json";                                       // 17
    LOGGER.info('[exportMongoclient]', fileContent, fileName);                                                         // 19
    var headers = {                                                                                                    // 21
        'Content-type': 'application/octet-stream',                                                                    // 22
        'Content-Disposition': 'attachment; filename=' + fileName                                                      // 23
    };                                                                                                                 // 21
    res.writeHead(200, headers);                                                                                       // 25
    res.end(JSON.stringify(fileContent));                                                                              // 26
});                                                                                                                    // 27
WebApp.connectHandlers.use('/export', function (req, res) {                                                            // 29
    var urlParts = decodeURI(req.url).split('&');                                                                      // 30
    var format = urlParts[0].substr(urlParts[0].indexOf('=') + 1);                                                     // 31
    var selectedCollection = urlParts[1].substr(urlParts[1].indexOf('=') + 1);                                         // 32
    var selector = urlParts[2].substr(urlParts[2].indexOf('=') + 1);                                                   // 33
    var cursorOptions = urlParts[3].substr(urlParts[3].indexOf('=') + 1);                                              // 34
    var sessionId = urlParts[4].substr(urlParts[4].indexOf('=') + 1);                                                  // 35
    LOGGER.info('[export]', format, selectedCollection, selector, cursorOptions, sessionId);                           // 37
    Meteor.call("find", selectedCollection, JSON.parse(selector), JSON.parse(cursorOptions), false, sessionId, function (err, result) {
        if (err || result.error) {                                                                                     // 40
            LOGGER.error('[export]', err, result.error);                                                               // 41
            res.writeHead(400);                                                                                        // 42
            res.end('Query error: ' + JSON.stringify(err) + " " + JSON.stringify(result.error));                       // 43
        } else {                                                                                                       // 44
            var headers = {                                                                                            // 45
                'Content-type': 'application/octet-stream',                                                            // 46
                'Content-Disposition': 'attachment; filename=export_result.' + format                                  // 47
            };                                                                                                         // 45
                                                                                                                       //
            if (format === 'JSON') {                                                                                   // 49
                res.writeHead(200, headers);                                                                           // 50
                res.end(JSON.stringify(result.result));                                                                // 51
            } else if (format === 'CSV') {                                                                             // 52
                res.writeHead(200, headers);                                                                           // 53
                res.end(Papa.unparse(result.result, {                                                                  // 54
                    delimiter: ";",                                                                                    // 54
                    newLine: "\n"                                                                                      // 54
                }));                                                                                                   // 54
            } else {                                                                                                   // 55
                res.writeHead(400);                                                                                    // 56
                res.end('Unsupported format: ' + format);                                                              // 57
            }                                                                                                          // 58
        }                                                                                                              // 59
    });                                                                                                                // 60
});                                                                                                                    // 61
WebApp.connectHandlers.use('/healthcheck', function (req, res) {                                                       // 64
    res.writeHead(200);                                                                                                // 65
    res.end('Server is up and running !');                                                                             // 66
});                                                                                                                    // 67
WebApp.connectHandlers.use("/download", function (req, res) {                                                          // 69
    var urlParts = decodeURI(req.url).split('&');                                                                      // 70
    var fileId = urlParts[0].substr(urlParts[0].indexOf('=') + 1);                                                     // 71
    var bucketName = urlParts[1].substr(urlParts[1].indexOf('=') + 1);                                                 // 72
    var sessionId = urlParts[2].substr(urlParts[2].indexOf('=') + 1);                                                  // 73
    LOGGER.info('[downloadFile]', fileId, bucketName, sessionId);                                                      // 75
    res.charset = 'UTF-8';                                                                                             // 77
                                                                                                                       //
    if (!bucketName || !fileId) {                                                                                      // 78
        LOGGER.info('[downloadFile]', 'file not found !');                                                             // 79
        res.writeHead(400);                                                                                            // 80
        res.end('File not found !');                                                                                   // 81
        return;                                                                                                        // 82
    }                                                                                                                  // 83
                                                                                                                       //
    try {                                                                                                              // 85
        var filesCollection = databasesBySessionId[sessionId].collection(bucketName + '.files');                       // 86
        filesCollection.find({                                                                                         // 87
            _id: new mongodbApi.ObjectId(fileId)                                                                       // 87
        }).limit(1).next(function (err, doc) {                                                                         // 87
            if (doc) {                                                                                                 // 88
                var bucket = new mongodbApi.GridFSBucket(databasesBySessionId[sessionId], {                            // 89
                    bucketName: bucketName                                                                             // 89
                });                                                                                                    // 89
                var headers = {                                                                                        // 90
                    'Content-type': 'application/octet-stream',                                                        // 91
                    'Content-Disposition': 'attachment; filename=' + encodeURIComponent(doc.filename)                  // 92
                };                                                                                                     // 90
                LOGGER.info('[downloadFile]', 'file found and started downloading...', headers);                       // 94
                var downloadStream = bucket.openDownloadStream(new mongodbApi.ObjectID(fileId));                       // 95
                res.writeHead(200, headers);                                                                           // 96
                var pipeStream = downloadStream.pipe(res);                                                             // 97
                pipeStream.on('finish', function () {                                                                  // 98
                    LOGGER.info('[downloadFile]', 'file has been downloaded successfully');                            // 99
                });                                                                                                    // 100
            } else {                                                                                                   // 102
                LOGGER.info('[downloadFile]', 'file not found !');                                                     // 103
                res.writeHead(400);                                                                                    // 104
                res.end('File not found !');                                                                           // 105
            }                                                                                                          // 106
        });                                                                                                            // 107
    } catch (ex) {                                                                                                     // 108
        LOGGER.error('[downloadFile]', ex);                                                                            // 110
        res.writeHead(500);                                                                                            // 111
        res.end('Unexpected error: ' + ex.message);                                                                    // 112
    }                                                                                                                  // 113
});                                                                                                                    // 115
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("/server/imports/internal/startup"));                                                             // 1
module.watch(require("/server/imports/publishers/publisher"));                                                         // 1
module.watch(require("/server/imports/webapp"));                                                                       // 1
module.watch(require("/server/imports/internal/internal_methods"));                                                    // 1
module.watch(require("/server/imports/mongodb/methods_common"));                                                       // 1
module.watch(require("/server/imports/mongodb/methods_admin"));                                                        // 1
module.watch(require("/server/imports/mongodb/methods_collection"));                                                   // 1
module.watch(require("/server/imports/mongodb/methods_dump_restore"));                                                 // 1
module.watch(require("/server/imports/mongodb/methods_gridfs"));                                                       // 1
module.watch(require("/server/imports/mongodb/methods_user_management"));                                              // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"package.json":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// package.json                                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "private": true,
  "name": "mongoclient",
  "version": "2.2.0",
  "devDependencies": {
    "eslint": "^4.2.0"
  },
  "dependencies": {
    "babel-runtime": "^6.18.0",
    "bootstrap-filestyle": "^1.2.1",
    "cheerio": "0.22.0",
    "codemirror": "^5.17.0",
    "cross-spawn": "^5.1.0",
    "datatables.net": "^1.10.13",
    "datatables.net-bs": "^1.10.13",
    "datatables.net-buttons": "^1.2.2",
    "datatables.net-buttons-bs": "^1.2.2",
    "datatables.net-responsive": "^2.1.0",
    "datatables.net-responsive-bs": "^2.1.0",
    "parse-mongo-url": "^1.1.1",
    "fbbk-json": "1.0.1",
    "jquery": "^2.2.0",
    "jquery-contextmenu": "2.4.4",
    "jsoneditor": "^5.5.6",
    "ladda": "^1.0.0",
    "meteor-node-stubs": "^0.2.3",
    "mongodb": "2.2.31",
    "spin.js": "^2.3.2",
    "toastr": "^2.1.2",
    "tunnel-ssh": "4.1.3",
    "winston": "2.3.1"
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/main.js");
//# sourceMappingURL=app.js.map
